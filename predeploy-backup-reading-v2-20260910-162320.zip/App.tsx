
import React, { useState, useEffect, useMemo, useRef } from 'react';
import { 
  Search, Plus, Upload, Moon, Sun, Menu,
  Trash2, Edit2, Loader2, Cloud, CheckCircle2, AlertCircle,
  Pin, Settings, Lock, CloudCog, Github, GitFork, GripVertical, Save, CheckSquare, LogOut, ExternalLink, X, Filter, CopyCheck, FileText
} from 'lucide-react';
import {
  DndContext,
  DragEndEvent,
  closestCenter,
  closestCorners,
  PointerSensor,
  useSensor,
  useSensors,
  KeyboardSensor,
} from '@dnd-kit/core';
import {
  arrayMove,
  SortableContext,
  sortableKeyboardCoordinates,
  verticalListSortingStrategy,
  rectSortingStrategy,
  useSortable,
} from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';
import { LinkItem, Category, DEFAULT_CATEGORIES, INITIAL_LINKS, WebDavConfig, AIConfig, SearchMode, ExternalSearchSource, SearchConfig, DashboardConfig, DEFAULT_DASHBOARD_CONFIG, INBOX_ID } from './types';
import Icon from './components/Icon';
import { useToast } from './components/Toast';
import { AI_CONFIG_KEY, DASHBOARD_CONFIG_KEY, SEARCH_HISTORY_KEY, SITE_SETTINGS_KEY, WORKBENCH_TOOLS_KEY, READ_LATER_KEY } from './constants/storageKeys';
import AuthModal from './components/AuthModal';
import ModalErrorBoundary from './components/ModalErrorBoundary';
import { getDefaultSearchSources } from './services/defaultSearchSources';
import { matchesFilters, matchesQuery, parseSearchQuery, preloadPinyin, sortByRelevance } from './services/searchService';
import { normalizeDashboardConfig } from './services/dashboardConfig';
import { applyBulkAction } from './services/bulkActions';
import { normalizeSearchHistory, recordSearch } from './services/searchHistory';
import { buildSearchIndex } from './services/searchIndex';
import { moveItem, type MoveDirection } from './services/linkOrdering';
import MobileBottomNav from './components/MobileBottomNav';
import InstallPrompt from './components/InstallPrompt';
import { softDeleteLinks } from './services/recycleBin';
import { mergeThreeWay } from './services/mergeService';
import { enqueuePendingMutation, readPendingMutations, replacePendingMutations } from './services/offlineStore';
import { createPendingMutationId, takeNextMutation } from './services/offlineQueue';
import { appendRecoverySnapshot, createRecoverySnapshot, normalizeRecoverySnapshots } from './services/recoverySnapshots';
import { RECOVERY_SNAPSHOTS_KEY } from './constants/storageKeys';
import { normalizeWorkbenchTools, type WorkbenchToolsState } from './services/workbenchTools';
import SpatialViewTransition from './components/SpatialViewTransition';
import { useAppBootstrap } from './hooks/useAppBootstrap';
import AppShell from './components/AppShell';
import PinnedSiteCard from './components/PinnedSiteCard';
import PinnedSitesPage from './components/PinnedSitesPage';
import PinnedSitesEmptyState from './components/PinnedSitesEmptyState';
import DesktopLibraryPage from './components/DesktopLibraryPage';
import TopWeather from './components/TopWeather';
import WebsiteSummaryPanel, { type WebsiteSummaryPanelState } from './components/WebsiteSummaryPanel';
import { readWorkspaceList, WORKSPACE_DATA_CHANGED_EVENT, writeWorkspaceList } from './services/workspaceStorage';
import type { QuickCaptureInput } from './components/QuickCaptureModal';
import { addReadLater, normalizeReadLater } from './services/readLaterService';
import { searchWorkspace, type UnifiedSearchResult } from './services/unifiedSearch';
import { normalizeInspirations } from './services/inspirationService';
import { normalizeGithubWatch } from './services/githubService';
import { readRssState } from './services/rssService';
import { readReadingDocuments, writeReadingDocuments } from './services/readingStorage';
import { readingDocumentFromRss, upsertReadingDocument } from './services/readingWorkspace';
import { normalizeWorkspaceSnapshot, readWorkspaceSnapshot, writeWorkspaceSnapshot } from './services/workspaceSnapshot';

// 非首屏模块按需加载，避免首页把所有弹窗、备份工具和二维码库一次性打进首包。
const CommandPalette = React.lazy(() => import('./components/CommandPalette'));
const LinkModal = React.lazy(() => import('./components/LinkModal'));
const CategoryManagerModal = React.lazy(() => import('./components/CategoryManagerModal'));
const BackupModal = React.lazy(() => import('./components/BackupModal'));
const CategoryAuthModal = React.lazy(() => import('./components/CategoryAuthModal'));
const CategoryActionAuthModal = React.lazy(() => import('./components/CategoryActionAuthModal'));
const ImportModal = React.lazy(() => import('./components/ImportModal'));
const SettingsModal = React.lazy(() => import('./components/SettingsModal'));
const SearchConfigModal = React.lazy(() => import('./components/SearchConfigModal'));
const ContextMenu = React.lazy(() => import('./components/ContextMenu'));
const QRCodeModal = React.lazy(() => import('./components/QRCodeModal'));
const LinkDetailsDrawer = React.lazy(() => import('./components/LinkDetailsDrawer'));
const SyncConflictModal = React.lazy(() => import('./components/SyncConflictModal'));
const OrganizeModeBar = React.lazy(() => import('./components/OrganizeModeBar'));
const AdvancedSearchBar = React.lazy(() => import('./components/AdvancedSearchBar'));
const RssPage = React.lazy(() => import('./components/RssPage'));
const WorkbenchPage = React.lazy(() => import('./components/WorkbenchPage'));
const InspirationPage = React.lazy(() => import('./components/InspirationPage'));
const ReadLaterPage = React.lazy(() => import('./components/ReadLaterPage'));
const GithubPage = React.lazy(() => import('./components/GithubPage'));
const InboxPage = React.lazy(() => import('./components/InboxPage'));
const ReadingWorkspacePage = React.lazy(() => import('./components/ReadingWorkspacePage'));

const getSearchSourceIconUrl = (url: string) => {
  try {
    const normalized = url.startsWith('http://') || url.startsWith('https://') ? url : `https://${url}`;
    const hostname = new URL(normalized).hostname;
    return `https://t3.gstatic.cn/faviconV2?client=SOCIAL&type=FAVICON&fallback_opts=TYPE,SIZE,URL&size=128&url=https://${hostname}`;
  } catch {
    return '';
  }
};

// --- 配置项 ---
// 项目核心仓库地址
const GITHUB_REPO_URL = 'https://github.com/Versior/CloudNav-abcd';

const LOCAL_STORAGE_KEY = 'cloudnav_data_cache';
const SEARCH_CONFIG_KEY = 'cloudnav_search_config';

const DEFAULT_AI_CONFIG: AIConfig = {
  provider: 'gemini',
  apiKey: '',
  baseUrl: '',
  model: 'gemini-2.5-flash',
};

const readLocalAIConfig = (): AIConfig => {
  try {
    const saved = localStorage.getItem(AI_CONFIG_KEY);
    if (saved) {
      const parsed = JSON.parse(saved) as Partial<AIConfig>;
      const storedKey = parsed.apiKey || '';
      const sessionKey = sessionStorage.getItem(`${AI_CONFIG_KEY}:session`) || storedKey;
      if (storedKey && sessionKey) {
        sessionStorage.setItem(`${AI_CONFIG_KEY}:session`, sessionKey);
        localStorage.setItem(AI_CONFIG_KEY, JSON.stringify({ ...parsed, apiKey: '' }));
      }
      return {
        ...DEFAULT_AI_CONFIG,
        ...parsed,
        apiKey: sessionKey,
        hasApiKey: !!parsed.hasApiKey || !!parsed.apiKey,
      };
    }
  } catch {}
  return DEFAULT_AI_CONFIG;
};

const mergeClientAIConfig = (remote: Partial<AIConfig> = {}, local = readLocalAIConfig()): AIConfig => ({
  provider: remote.provider || local.provider || 'gemini',
  apiKey: remote.apiKey || local.apiKey || '',
  baseUrl: remote.baseUrl !== undefined ? remote.baseUrl : local.baseUrl || '',
  model: remote.model || local.model || 'gemini-2.5-flash',
  hasApiKey: !!remote.hasApiKey || !!remote.apiKey || !!local.apiKey || !!local.hasApiKey,
});

const saveLocalAIConfig = (config: AIConfig): AIConfig => {
  const next = {
    ...DEFAULT_AI_CONFIG,
    ...config,
    hasApiKey: !!config.hasApiKey || !!config.apiKey,
  };
  try {
    if (next.apiKey) sessionStorage.setItem(`${AI_CONFIG_KEY}:session`, next.apiKey);
    else sessionStorage.removeItem(`${AI_CONFIG_KEY}:session`);
    localStorage.setItem(AI_CONFIG_KEY, JSON.stringify({ ...next, apiKey: '' }));
  } catch {}
  return next;
};

const fetchWithTimeout = async (input: RequestInfo | URL, init: RequestInit = {}, timeoutMs = 12000) => {
  const controller = new AbortController();
  const timeout = window.setTimeout(() => controller.abort(), timeoutMs);
  try {
    return await fetch(input, { ...init, signal: controller.signal });
  } finally {
    window.clearTimeout(timeout);
  }
};

const mergeLocalVisitState = (incomingLinks: LinkItem[]): LinkItem[] => {
  try {
    const stored = localStorage.getItem(LOCAL_STORAGE_KEY);
    if (!stored) return incomingLinks;
    const localLinks = (JSON.parse(stored).links || []) as LinkItem[];
    const localById = new Map(localLinks.map(link => [link.id, link]));
    return incomingLinks.map(link => {
      const local = localById.get(link.id);
      if (!local) return link;
      const visitCount = Math.max(link.visitCount || 0, local.visitCount || 0);
      const lastVisitedAt = Math.max(link.lastVisitedAt || 0, local.lastVisitedAt || 0) || undefined;
      return { ...link, visitCount, lastVisitedAt };
    });
  } catch {
    return incomingLinks;
  }
};

const normalizeCategories = (value: unknown): Category[] => {
  const source = Array.isArray(value) ? value : DEFAULT_CATEGORIES;
  const cleaned = source.filter((item): item is Category => !!item && typeof item === 'object' && typeof (item as Category).id === 'string' && typeof (item as Category).name === 'string');
  return cleaned.length > 0 ? cleaned : DEFAULT_CATEGORIES;
};

const normalizeLinks = (value: unknown): LinkItem[] => {
  const source = Array.isArray(value) ? value : INITIAL_LINKS;
  const cleaned = source.filter((item): item is LinkItem => !!item && typeof item === 'object' && typeof (item as LinkItem).id === 'string' && typeof (item as LinkItem).title === 'string' && typeof (item as LinkItem).url === 'string');
  return cleaned.length > 0 ? cleaned : INITIAL_LINKS;
};

const readLocalData = (): { links: LinkItem[]; categories: Category[] } => {
  try {
    const stored = localStorage.getItem(LOCAL_STORAGE_KEY);
    if (!stored) return { links: INITIAL_LINKS, categories: DEFAULT_CATEGORIES };

    const parsed = JSON.parse(stored);
    let categories = normalizeCategories(parsed.categories);
    if (!categories.some(category => category.id === 'common')) {
      categories = [{ id: 'common', name: '常用推荐', icon: 'Star' }, ...categories];
    } else {
      const commonIndex = categories.findIndex(category => category.id === 'common');
      if (commonIndex > 0) {
        const commonCategory = categories[commonIndex];
        categories = [commonCategory, ...categories.slice(0, commonIndex), ...categories.slice(commonIndex + 1)];
      }
    }

    const validCategoryIds = new Set(categories.map(category => category.id));
    const links = normalizeLinks(parsed.links).map(link => (
      validCategoryIds.has(link.categoryId) ? link : { ...link, categoryId: 'common' }
    ));
    return { links, categories };
  } catch {
    return { links: INITIAL_LINKS, categories: DEFAULT_CATEGORIES };
  }
};

const readLocalDashboardConfig = (): DashboardConfig => {
  try {
    const saved = localStorage.getItem(DASHBOARD_CONFIG_KEY);
    return normalizeDashboardConfig(saved ? JSON.parse(saved) : DEFAULT_DASHBOARD_CONFIG);
  } catch {
    return { ...DEFAULT_DASHBOARD_CONFIG, order: [...DEFAULT_DASHBOARD_CONFIG.order], hidden: [] };
  }
};

const createSyncConflictFingerprint = (
  version: number,
  localSnapshot: { links: LinkItem[]; categories: Category[] },
  cloudSnapshot: { links: LinkItem[]; categories: Category[] },
) => JSON.stringify({ version, local: localSnapshot, cloud: cloudSnapshot });

function App() {
  const { showToast } = useToast();
  const { snapshot: bootstrapSnapshot, refresh: refreshBootstrap } = useAppBootstrap();
  const [isPaletteOpen, setIsPaletteOpen] = useState(false);
  const [selectedLinkId, setSelectedLinkId] = useState<string | null>(null);
  const [unifiedSearchTarget, setUnifiedSearchTarget] = useState<UnifiedSearchResult | null>(null);
  const [detailsOrigin, setDetailsOrigin] = useState<'right' | 'bottom'>('right');
  const [isOrganizeMode, setIsOrganizeMode] = useState(false);
  const [isAiOrganizing, setIsAiOrganizing] = useState(false);
  const [organizeIndex, setOrganizeIndex] = useState(0);
  const [isSyncConflict, setIsSyncConflict] = useState(false);
  const [isAdvancedFilterOpen, setIsAdvancedFilterOpen] = useState(false);
  const [advancedFilters, setAdvancedFilters] = useState<Record<string, string | boolean | undefined>>({});
  const [syncConflictResolve, setSyncConflictResolve] = useState<{ useLocal: () => void; useCloud: () => void; merge: () => void } | null>(null);
  const [syncConflictPreview, setSyncConflictPreview] = useState<{ links: number; categories: number } | null>(null);

  // Visit tracking stays local so opening links never waits on cloud sync.
  const recordVisit = (id: string) => {
    const nextLinks = links.map(l =>
      l.id === id ? { ...l, lastVisitedAt: Date.now(), visitCount: (l.visitCount || 0) + 1 } : l
    );
    setLinks(nextLinks);
    localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify({ links: nextLinks, categories }));
  };

  // --- State ---
  const [localInitialData] = useState(() => ({
    links: bootstrapSnapshot.links,
    categories: bootstrapSnapshot.categories,
  }));
  const [links, setLinks] = useState<LinkItem[]>(localInitialData.links);
  const [categories, setCategories] = useState<Category[]>(localInitialData.categories);
  const [activeView, setActiveView] = useState<'links' | 'workbench' | 'rss' | 'inspiration' | 'read-later' | 'github' | 'inbox' | 'reading'>('links');
  const [quickCaptureSeed, setQuickCaptureSeed] = useState<Partial<QuickCaptureInput> | undefined>(undefined);
  const [readingCaptureSeed, setReadingCaptureSeed] = useState<{ title?: string; url?: string } | undefined>(undefined);
  const [dashboardConfig, setDashboardConfig] = useState<DashboardConfig>(() => bootstrapSnapshot.dashboardConfig);
  const [workbenchTools, setWorkbenchTools] = useState<WorkbenchToolsState>(() => bootstrapSnapshot.workbenchTools);
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [searchHistory, setSearchHistory] = useState<string[]>(() => {
    try { return normalizeSearchHistory(JSON.parse(localStorage.getItem(SEARCH_HISTORY_KEY) || '[]')); } catch { return []; }
  });
  const [pinyinReady, setPinyinReady] = useState(false);
  const [darkMode, setDarkMode] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [isOnline, setIsOnline] = useState(() => navigator.onLine);
  const [workspaceRevision, setWorkspaceRevision] = useState(0);

  // Search Mode State
  const [searchMode, setSearchMode] = useState<SearchMode>('external');
  const [externalSearchSources, setExternalSearchSources] = useState<ExternalSearchSource[]>([]);
  const [isLoadingSearchConfig, setIsLoadingSearchConfig] = useState(true);

  const unifiedSearchResults = useMemo(() => {
    if (searchMode !== 'internal' || !searchQuery.trim()) return [];
    try {
      return searchWorkspace(searchQuery, {
        links,
        articles: readRssState().articles,
        inspirations: normalizeInspirations(JSON.parse(localStorage.getItem('cloudnav_inspirations') || '[]')),
        readLater: normalizeReadLater(JSON.parse(localStorage.getItem(READ_LATER_KEY) || '[]')),
        githubWatch: normalizeGithubWatch(JSON.parse(localStorage.getItem('cloudnav_github_watch') || '[]')),
        readingDocuments: readReadingDocuments(),
      });
    } catch { return []; }
  }, [links, searchMode, searchQuery, workspaceRevision]);
  
  // Category Security State
  const [unlockedCategoryIds, setUnlockedCategoryIds] = useState<Set<string>>(new Set());

  // WebDAV Config State
  const [webDavConfig, setWebDavConfig] = useState<WebDavConfig>({
      url: 'https://webdav.opendrive.com/',
      username: '',
      password: '',
      enabled: false
  });

  // AI Config State
  const [aiConfig, setAiConfig] = useState<AIConfig>(() => readLocalAIConfig());
  const [websiteSummary, setWebsiteSummary] = useState<WebsiteSummaryPanelState | null>(null);
  const websiteSummaryRequestRef = useRef(0);

  const openWebsiteWithSummary = async (link: LinkItem, options: { openExternal?: boolean } = {}) => {
    const openExternal = options.openExternal !== false;
    if (openExternal) {
      // 先开站点，再异步抓取正文，避免 AI 请求拖慢用户真正想打开的页面。
      window.open(link.url, '_blank', 'noopener,noreferrer');
      recordVisit(link.id);
    }

    const requestId = ++websiteSummaryRequestRef.current;
    const panelLink = { id: link.id, title: link.title, url: link.url, description: link.description };
    // 摘要模块按需加载，首页打开网站时不会把 AI 依赖塞进首包。
    const { getCachedWebsiteSummary, summarizeWebsite } = await import('./services/websiteSummaryService');
    const cached = getCachedWebsiteSummary(link.url);
    if (cached) {
      setWebsiteSummary({ link: panelLink, status: 'ready', result: cached });
      return;
    }

    if (!aiConfig.apiKey && !aiConfig.hasApiKey) {
      setWebsiteSummary({
        link: panelLink,
        status: 'error',
        error: '请先在设置 → AI 中配置 API Key，网站仍已正常打开。',
      });
      return;
    }

    setWebsiteSummary({ link: panelLink, status: 'loading' });
    try {
      const result = await summarizeWebsite(link, aiConfig);
      if (requestId !== websiteSummaryRequestRef.current) return;
      setWebsiteSummary({ link: panelLink, status: 'ready', result });
    } catch (error) {
      if (requestId !== websiteSummaryRequestRef.current) return;
      setWebsiteSummary({
        link: panelLink,
        status: 'error',
        error: error instanceof Error ? error.message : '页面读取失败，请稍后重试。',
      });
    }
  };

  // Site Settings State
  const [siteSettings, setSiteSettings] = useState(() => {
      const saved = localStorage.getItem(SITE_SETTINGS_KEY);
      if (saved) {
          try {
              return JSON.parse(saved);
          } catch (e) {}
      }
      return {
          title: 'CloudNav - 我的导航',
          navTitle: 'CloudNav',
          favicon: '',
          cardStyle: 'detailed' as const,
          passwordExpiryDays: 7
      };
  });
  
  // Modals
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isAuthOpen, setIsAuthOpen] = useState(false);
  const [isCatManagerOpen, setIsCatManagerOpen] = useState(false);
  const [categoryManagerEditId, setCategoryManagerEditId] = useState('');
  const [isBackupModalOpen, setIsBackupModalOpen] = useState(false);
  const [isImportModalOpen, setIsImportModalOpen] = useState(false);
  const [isSettingsModalOpen, setIsSettingsModalOpen] = useState(false);
  const [isSearchConfigModalOpen, setIsSearchConfigModalOpen] = useState(false);
  const [catAuthModalData, setCatAuthModalData] = useState<Category | null>(null);
  
  const [editingLink, setEditingLink] = useState<LinkItem | undefined>(undefined);
  // State for data pre-filled from Bookmarklet
  const [prefillLink, setPrefillLink] = useState<Partial<LinkItem> | undefined>(undefined);
  
  // Sync State
  const [syncStatus, setSyncStatus] = useState<'idle' | 'saving' | 'saved' | 'error'>('idle');
  const [pendingSyncCount, setPendingSyncCount] = useState(0);
  const [authToken, setAuthToken] = useState<boolean>(false);
  const cloudVersionRef = useRef(0);
  const cloudBaseRef = useRef<{ links: LinkItem[]; categories: Category[] }>({ links: localInitialData.links, categories: localInitialData.categories });
  const syncTimerRef = useRef<number | null>(null);
  const syncInFlightRef = useRef(false);
  const queuedSyncRef = useRef<{ links: LinkItem[]; categories: Category[] } | null>(null);
  const syncConflictFingerprintRef = useRef<string | null>(null);
  const syncConflictOpenRef = useRef(false);
  const [extensionToken, setExtensionToken] = useState('');
  const [requiresAuth, setRequiresAuth] = useState<boolean | null>(null); // null表示未检查，true表示需要认证，false表示不需要
  const [isCheckingAuth, setIsCheckingAuth] = useState(true);
  
  // Sort State
  const [isSortingMode, setIsSortingMode] = useState<string | null>(null); // 存储正在排序的分类ID，null表示不在排序模式
  const [isSortingPinned, setIsSortingPinned] = useState(false); // 是否正在排序置顶链接
  
  // Batch Edit State
  const [isBatchEditMode, setIsBatchEditMode] = useState(false); // 是否处于批量编辑模式
  const [selectedLinks, setSelectedLinks] = useState<Set<string>>(new Set()); // 选中的链接ID集合
  
  // Sub-category State
  const [hoveredCategory, setHoveredCategory] = useState<string | null>(null); // 当前悬浮的一级分类ID
  const [hoveredCategoryTop, setHoveredCategoryTop] = useState<number>(0); // 当前悬浮的一级分类的垂直位置
  
  // Context Menu State
  const [contextMenu, setContextMenu] = useState<{
    isOpen: boolean;
    position: { x: number; y: number };
    link: LinkItem | null;
    category: Category | null;
    type: 'link' | 'category';
  }>({
    isOpen: false,
    position: { x: 0, y: 0 },
    link: null,
    category: null,
    type: 'link'
  });
  const [aiSettingsCategoryId, setAiSettingsCategoryId] = useState('');
  const [aiSettingsAction, setAiSettingsAction] = useState<'organize' | 'rename' | 'structure' | ''>('');
  const [settingsInitialTab, setSettingsInitialTab] = useState<'site' | 'ai' | 'tools' | 'duplicates' | 'health' | 'recycle' | undefined>(undefined);
  
  // QR Code Modal State
  const [qrCodeModal, setQrCodeModal] = useState<{
    isOpen: boolean;
    url: string;
    title: string;
  }>({
    isOpen: false,
    url: '',
    title: ''
  });

  // Mobile Search State
  const [isMobileSearchOpen, setIsMobileSearchOpen] = useState(false);
  
  // Category Action Auth State
  const [categoryActionAuth, setCategoryActionAuth] = useState<{
    isOpen: boolean;
    action: 'edit' | 'delete';
    categoryId: string;
    categoryName: string;
  }>({
    isOpen: false,
    action: 'edit',
    categoryId: '',
    categoryName: ''
  });

  const openWorkbench = () => {
    setActiveView('workbench');
    setSelectedCategory('all');
    setSearchQuery('');
    setIsOrganizeMode(false);
    setSidebarOpen(false);
  };

  const openLinksView = (categoryId = 'all') => {
    setActiveView('links');
    setSelectedCategory(categoryId);
    setSearchQuery('');
    setSidebarOpen(false);
  };

  const openRssReader = () => {
    setActiveView('rss');
    setSelectedCategory('all');
    setSearchQuery('');
    setIsOrganizeMode(false);
    setSidebarOpen(false);
  };

  const saveRssArticleToLinks = (article: import('./types').RssArticle) => {
    setPrefillLink({
      title: article.title,
      url: article.url,
      description: article.summary || `来自 ${article.sourceTitle || 'RSS'} 的文章`,
      categoryId: 'common',
    });
    setEditingLink(undefined);
    if (!authToken) {
      setIsAuthOpen(true);
      return;
    }
    setIsModalOpen(true);
  };

  const saveRssArticleToReadLater = (article: import('./types').RssArticle) => {
    try {
      const current = readWorkspaceList(READ_LATER_KEY, normalizeReadLater);
      const next = addReadLater(current, { kind: 'rss', title: article.title, url: article.url, source: article.sourceTitle, summary: article.aiSummary || article.summary });
      writeWorkspaceList(READ_LATER_KEY, next, normalizeReadLater);
      showToast('已加入稍后阅读', { type: 'success' });
    } catch (error) {
      showToast(error instanceof Error ? error.message : '加入稍后阅读失败', { type: 'error' });
    }
  };

  const saveRssArticleToReading = (article: import('./types').RssArticle) => {
    try {
      const next = upsertReadingDocument(readReadingDocuments(), readingDocumentFromRss(article));
      writeReadingDocuments(next);
      showToast('已保存到阅读 Inbox', { type: 'success' });
    } catch (error) {
      showToast(error instanceof Error ? error.message : '保存到阅读 Inbox 失败', { type: 'error' });
    }
  };

  const saveLinkToReadLater = (link: LinkItem) => {
    try {
      const current = readWorkspaceList(READ_LATER_KEY, normalizeReadLater);
      const next = addReadLater(current, { kind: 'website', title: link.title, url: link.url, source: '网站库', summary: link.description });
      writeWorkspaceList(READ_LATER_KEY, next, normalizeReadLater);
      showToast('网站已加入稍后阅读', { type: 'success' });
    } catch (error) {
      showToast(error instanceof Error ? error.message : '加入稍后阅读失败', { type: 'error' });
    }
  };

  const captureRssArticle = (article: import('./types').RssArticle) => {
    openInspiration({
      title: article.title,
      content: article.aiSummary || article.summary || '待补充：这篇文章值得记录什么？',
      type: 'bookmark',
      sourceUrl: article.url,
      sourceTitle: article.sourceTitle || 'RSS 资讯',
      tags: article.aiTags || ['RSS'],
    });
  };

  const updateDashboardConfig = (nextConfig: DashboardConfig) => {
    const normalized = normalizeDashboardConfig(nextConfig);
    setDashboardConfig(normalized);
    localStorage.setItem(DASHBOARD_CONFIG_KEY, JSON.stringify(normalized));
    if (authToken) {
      void fetch('/api/storage', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ saveConfig: 'dashboard', config: normalized }),
      }).catch(error => console.warn('Failed to save dashboard config.', error));
    }
  };

  const updateWorkbenchTools = (next: WorkbenchToolsState) => {
    const normalized = normalizeWorkbenchTools(next);
    setWorkbenchTools(normalized);
    localStorage.setItem(WORKBENCH_TOOLS_KEY, JSON.stringify(normalized));
    if (authToken && navigator.onLine) scheduleCloudSync(links, categories);
  };

  const saveSearchQuery = (query: string) => {
    const next = recordSearch(searchHistory, query);
    setSearchHistory(next);
    localStorage.setItem(SEARCH_HISTORY_KEY, JSON.stringify(next));
  };
  
  // --- Helpers & Sync Logic ---

  const loadFromLocal = () => {
    const localData = readLocalData();
    setLinks(localData.links);
    setCategories(localData.categories);
  };

  const applyCloudData = (remoteLinks: LinkItem[], remoteCategories: Category[], version?: number, remoteWorkspace?: unknown) => {
    setLinks(remoteLinks);
    setCategories(remoteCategories);
    cloudBaseRef.current = { links: remoteLinks, categories: remoteCategories };
    if (typeof version === 'number') cloudVersionRef.current = version;
    if (remoteWorkspace) writeWorkspaceSnapshot(normalizeWorkspaceSnapshot(remoteWorkspace), false);
    localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify({ links: remoteLinks, categories: remoteCategories, version: cloudVersionRef.current }));
  };

  const queueOfflineMutation = async (newLinks: LinkItem[], newCategories: Category[]) => {
    await enqueuePendingMutation({
      id: createPendingMutationId(),
      createdAt: Date.now(),
      links: newLinks,
      categories: newCategories,
      baseVersion: cloudVersionRef.current,
      workspace: readWorkspaceSnapshot(),
    });
    setPendingSyncCount(1);
    setSyncStatus('error');
  };

  const syncToCloud = async (newLinks: LinkItem[], newCategories: Category[], baseVersion = cloudVersionRef.current, workspace = readWorkspaceSnapshot()) => {
    if (syncInFlightRef.current) {
      queuedSyncRef.current = { links: newLinks, categories: newCategories };
      return false;
    }
    syncInFlightRef.current = true;
    if (!navigator.onLine) {
      try {
        await queueOfflineMutation(newLinks, newCategories);
        return false;
      } finally {
        syncInFlightRef.current = false;
      }
    }
    setSyncStatus('saving');
    try {
        const controller = new AbortController();
        const timeout = window.setTimeout(() => controller.abort(), 12000);
        let response: Response;
        try {
          response = await fetch('/api/storage', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ links: newLinks, categories: newCategories, workspace, baseVersion }),
            signal: controller.signal,
          });
        } finally {
          window.clearTimeout(timeout);
        }

        if (response.status === 409) {
            try {
                const conflict = await response.json();
                const cloudData = conflict?.data;
                if (cloudData && Array.isArray(cloudData.links)) {
                    cloudVersionRef.current = typeof cloudData.version === 'number' ? cloudData.version : cloudVersionRef.current;
                    const localSnapshot = { links: newLinks, categories: newCategories };
                    const cloudSnapshot = { links: cloudData.links as LinkItem[], categories: (cloudData.categories || []) as Category[] };
                    const conflictFingerprint = createSyncConflictFingerprint(cloudVersionRef.current, localSnapshot, cloudSnapshot);
                    if (syncConflictFingerprintRef.current === conflictFingerprint) {
                      setSyncStatus('error');
                      return false;
                    }
                    syncConflictFingerprintRef.current = conflictFingerprint;
                    syncConflictOpenRef.current = true;
                    queuedSyncRef.current = null;
                    const mergeResult = mergeThreeWay(cloudBaseRef.current, localSnapshot, cloudSnapshot);
                    setSyncConflictPreview({
                      links: mergeResult.linkConflicts,
                      categories: mergeResult.categoryConflicts,
                    });
                    setSyncConflictResolve({
                        useLocal: () => {
                          syncConflictOpenRef.current = false;
                          syncConflictFingerprintRef.current = null;
                          void replacePendingMutations([]);
                          void syncToCloud(localSnapshot.links, localSnapshot.categories);
                        },
                        useCloud: () => {
                             syncConflictOpenRef.current = false;
                             syncConflictFingerprintRef.current = null;
                             void replacePendingMutations([]);
                             applyCloudData(cloudSnapshot.links, cloudSnapshot.categories, cloudData.version, cloudData.workspace);
                        },
                        merge: () => {
                            syncConflictOpenRef.current = false;
                            syncConflictFingerprintRef.current = null;
                            void replacePendingMutations([]);
                            updateData(mergeResult.data.links, mergeResult.data.categories);
                        },
                    });
                    setIsSyncConflict(true);
                }
            } catch {}
            setSyncStatus('error');
            return false;
        }

        if (response.status === 401) {
            setAuthToken(false);
            setIsAuthOpen(true);
            setSyncStatus('error');
            return false;
        }

        if (!response.ok) throw new Error('Network response was not ok');

        const result = await response.json().catch(() => ({}));
        if (typeof result.version === 'number') cloudVersionRef.current = result.version;

        cloudBaseRef.current = { links: newLinks, categories: newCategories };
        syncConflictFingerprintRef.current = null;
        syncConflictOpenRef.current = false;
        if (result.workspace) writeWorkspaceSnapshot(normalizeWorkspaceSnapshot(result.workspace), false);
        await replacePendingMutations([]);
        setPendingSyncCount(0);

        setSyncStatus('saved');
        setTimeout(() => setSyncStatus('idle'), 2000);
        return true;
    } catch (error) {
        console.error("Sync failed", error);
        await queueOfflineMutation(newLinks, newCategories);
        setSyncStatus('error');
        return false;
    } finally {
      syncInFlightRef.current = false;
      if (!syncConflictOpenRef.current && navigator.onLine) {
        const queued = queuedSyncRef.current;
        queuedSyncRef.current = null;
        if (queued) window.setTimeout(() => void syncToCloud(queued.links, queued.categories), 0);
      }
    }
  };

  const flushPendingSync = async () => {
    if (!authToken || !navigator.onLine) return;
    const pending = await readPendingMutations();
    const [next] = takeNextMutation(pending);
    if (!next) { setPendingSyncCount(0); return; }
    const ok = await syncToCloud(next.links as LinkItem[], next.categories as Category[], next.baseVersion, next.workspace ? normalizeWorkspaceSnapshot(next.workspace) : readWorkspaceSnapshot());
    if (ok) await replacePendingMutations([]);
  };

  const scheduleCloudSync = (newLinks: LinkItem[], newCategories: Category[]) => {
    if (syncTimerRef.current !== null) window.clearTimeout(syncTimerRef.current);
    syncTimerRef.current = window.setTimeout(() => {
      syncTimerRef.current = null;
      void syncToCloud(newLinks, newCategories);
    }, 220);
  };

  useEffect(() => {
    const handleWorkspaceChange = () => {
      setWorkspaceRevision(value => value + 1);
      if (authToken && navigator.onLine) scheduleCloudSync(links, categories);
    };
    window.addEventListener(WORKSPACE_DATA_CHANGED_EVENT, handleWorkspaceChange);
    return () => window.removeEventListener(WORKSPACE_DATA_CHANGED_EVENT, handleWorkspaceChange);
  }, [authToken, links, categories]);

  const updateData = (newLinks: LinkItem[], newCategories: Category[]) => {
      try {
        const currentRaw = localStorage.getItem(RECOVERY_SNAPSHOTS_KEY);
        const snapshot = createRecoverySnapshot({ links, categories });
        localStorage.setItem(RECOVERY_SNAPSHOTS_KEY, JSON.stringify(appendRecoverySnapshot(currentRaw ? JSON.parse(currentRaw) : [], snapshot)));
      } catch {}
      // 1. Optimistic UI Update
      setLinks(newLinks);
      setCategories(newCategories);
      
      // 2. Save to Local Cache
       try {
         localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify({ links: newLinks, categories: newCategories }));
       } catch {
         showToast('本地空间写入失败，当前修改尚未可靠保存', { type: 'error' });
       }

      // 3. Sync to Cloud (if authenticated)
       if (authToken && navigator.onLine) {
           scheduleCloudSync(newLinks, newCategories);
       } else if (authToken) {
           void queueOfflineMutation(newLinks, newCategories);
       }
  };

  // --- Context Menu Functions ---
  const handleContextMenu = (event: React.MouseEvent, link: LinkItem) => {
    event.preventDefault();
    event.stopPropagation();

    if (isBatchEditMode) return;

    setContextMenu({
      isOpen: true,
      position: { x: event.clientX, y: event.clientY },
      link,
      category: null,
      type: 'link'
    });
  };

  const handleCategoryContextMenu = (event: React.MouseEvent, category: Category) => {
    event.preventDefault();
    event.stopPropagation();

    setHoveredCategory(null);
    setContextMenu({
      isOpen: true,
      position: { x: event.clientX, y: event.clientY },
      link: null,
      category,
      type: 'category'
    });
  };

  const closeContextMenu = () => {
    setContextMenu({
      isOpen: false,
      position: { x: 0, y: 0 },
      link: null,
      category: null,
      type: 'link'
    });
  };

  const copyLinkToClipboard = () => {
    if (!contextMenu.link) return;
    
    navigator.clipboard.writeText(contextMenu.link.url)
      .then(() => {
        // 可以添加一个短暂的提示
        console.log('链接已复制到剪贴板');
      })
      .catch(err => {
        console.error('复制链接失败:', err);
      });
    
    closeContextMenu();
  };

  const showQRCode = () => {
    if (!contextMenu.link) return;
    
    setQrCodeModal({
      isOpen: true,
      url: contextMenu.link.url,
      title: contextMenu.link.title
    });
    
    closeContextMenu();
  };

  const editLinkFromContextMenu = () => {
    if (!contextMenu.link) return;
    
    setEditingLink(contextMenu.link);
    setIsModalOpen(true);
    closeContextMenu();
  };

  const deleteLinkFromContextMenu = () => {
    if (!contextMenu.link) return;
    
    if (window.confirm(`确定要删除"${contextMenu.link.title}"吗？`)) {
      const newLinks = softDeleteLinks(links, [contextMenu.link!.id]);
      updateData(newLinks, categories);
    }
    
    closeContextMenu();
  };

  const togglePinFromContextMenu = () => {
    if (!contextMenu.link) return;

    const linkToToggle = links.find(l => l.id === contextMenu.link!.id);
    if (!linkToToggle) return;

    const updated = links.map(l => {
      if (l.id === contextMenu.link!.id) {
        const isPinned = !l.pinned;
        return {
          ...l,
          pinned: isPinned,
          pinnedOrder: isPinned ? links.filter(link => link.pinned).length : undefined
        };
      }
      return l;
    });

    updateData(updated, categories);
    closeContextMenu();
  };

  const openCategoryFromContextMenu = () => {
    if (!contextMenu.category) return;
    handleCategoryClick(contextMenu.category);
  };

  const editCategoryFromContextMenu = () => {
    const category = contextMenu.category;
    if (!category) return;
    if (!authToken) {
      setIsAuthOpen(true);
      return;
    }
    if (category.id === 'common') {
      setIsCatManagerOpen(true);
      return;
    }
    openCategoryActionAuth('edit', category.id, category.name);
  };

  const openAICategoryAction = (action: 'organize' | 'rename' | 'structure') => {
    if (!contextMenu.category) return;
    if (!authToken) {
      setIsAuthOpen(true);
      return;
    }
    if ((action === 'rename' || action === 'structure') && (contextMenu.category.id === 'common' || contextMenu.category.id === '__inbox__')) {
      alert(action === 'rename' ? '该系统文件夹不支持 AI 重命名' : '该系统文件夹不支持 AI 拆分');
      return;
    }
    setAiSettingsCategoryId(contextMenu.category.id);
    setAiSettingsAction(action);
    setIsSettingsModalOpen(true);
  };

  const organizeCategoryFromContextMenu = () => openAICategoryAction('organize');
  const renameCategoryFromContextMenu = () => openAICategoryAction('rename');
  const structureCategoryFromContextMenu = () => openAICategoryAction('structure');

  const deleteCategoryFromContextMenu = () => {
    const category = contextMenu.category;
    if (!category || category.id === 'common') return;
    if (!authToken) {
      setIsAuthOpen(true);
      return;
    }
    openCategoryActionAuth('delete', category.id, category.name);
  };

  // 加载链接图标缓存
  const loadLinkIcons = async (linksToLoad: LinkItem[]) => {
    if (!authToken) return; // 只有在已登录状态下才加载图标缓存
    
    const updatedLinks = [...linksToLoad];
    const domainsToFetch: string[] = [];
    
    // 收集所有链接的域名（包括已有图标的链接）
    for (const link of updatedLinks) {
      if (link.url) {
        try {
          let domain = link.url;
          if (!link.url.startsWith('http://') && !link.url.startsWith('https://')) {
            domain = 'https://' + link.url;
          }
          
          if (domain.startsWith('http://') || domain.startsWith('https://')) {
            const urlObj = new URL(domain);
            domain = urlObj.hostname;
            domainsToFetch.push(domain);
          }
        } catch (e) {
          console.error("Failed to parse URL for icon loading", e);
        }
      }
    }
    
    // 批量获取图标
    if (domainsToFetch.length > 0) {
      const iconPromises = domainsToFetch.map(async (domain) => {
        try {
          const response = await fetch(`/api/storage?getConfig=favicon&domain=${encodeURIComponent(domain)}`);
          if (response.ok) {
            const data = await response.json();
            if (data.cached && data.icon) {
              return { domain, icon: data.icon };
            }
          }
        } catch (error) {
          console.log(`Failed to fetch cached icon for ${domain}`, error);
        }
        return null;
      });
      
      const iconResults = await Promise.all(iconPromises);
      
      // 更新链接的图标
      iconResults.forEach(result => {
        if (result) {
          const linkToUpdate = updatedLinks.find(link => {
            if (!link.url) return false;
            try {
              let domain = link.url;
              if (!link.url.startsWith('http://') && !link.url.startsWith('https://')) {
                domain = 'https://' + link.url;
              }
              
              if (domain.startsWith('http://') || domain.startsWith('https://')) {
                const urlObj = new URL(domain);
                return urlObj.hostname === result.domain;
              }
            } catch (e) {
              return false;
            }
            return false;
          });
          
          if (linkToUpdate) {
            // 只有当链接没有图标，或者当前图标是 gstatic.cn 生成的，或者缓存中的图标是自定义图标时才更新
            if (!linkToUpdate.icon || 
                linkToUpdate.icon.includes('gstatic.cn') || 
                !result.icon.includes('gstatic.cn')) {
              linkToUpdate.icon = result.icon;
            }
          }
        }
      });
      
      // 更新状态
      setLinks(updatedLinks);
    }
  };

  // --- Effects ---

  useEffect(() => {
    // Theme init
    if (localStorage.getItem('theme') === 'dark' || (!('theme' in localStorage) && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
      setDarkMode(true);
      document.documentElement.classList.add('dark');
    }

    // Handle URL Params for Bookmarklet (Add Link)
    const urlParams = new URLSearchParams(window.location.search);
    const addUrl = urlParams.get('add_url');
    if (addUrl) {
        const addTitle = urlParams.get('add_title') || '';
        // Clean URL params to avoid re-triggering on refresh
        window.history.replaceState({}, '', window.location.pathname);
        
        setPrefillLink({
            title: addTitle,
            url: addUrl,
            categoryId: 'common' // Default, Modal will handle selection
        });
        setEditingLink(undefined);
        setIsModalOpen(true);
    } else {
        const sharedText = urlParams.get('text') || '';
        const sharedUrl = urlParams.get('url') || sharedText.match(/https?:\/\/[^\s]+/i)?.[0] || '';
        if (sharedUrl) {
          setReadingCaptureSeed({ title: urlParams.get('title') || '', url: sharedUrl });
          setActiveView('reading');
          window.history.replaceState({}, '', window.location.pathname);
        }
    }

    // Initial Data Fetch
    const initData = async () => {
        let authenticated = false;
        try {
            const authRes = await fetchWithTimeout('/api/storage?checkAuth=true');
            if (authRes.ok) {
                const authData = await authRes.json();
                authenticated = !!authData.authenticated;
                setAuthToken(authenticated);
                setExtensionToken(authData.extensionToken || '');
                setRequiresAuth(authData.requiresAuth);

                if (authData.requiresAuth && !authenticated) {
                    setIsCheckingAuth(false);
                    setIsAuthOpen(true);
                    return;
                }
            }
        } catch (e) {
            console.warn("Failed to check auth requirement.", e);
        }

        // 认证通过后，配置和内容请求互不依赖；本地快照已经先行渲染。
        const [webDavConfigRes, aiConfigRes] = await Promise.all([
          fetchWithTimeout('/api/storage?getConfig=webdav').catch((error) => {
            console.warn("Failed to fetch WebDAV config.", error);
            return null;
            }),
            fetchWithTimeout('/api/storage?getConfig=ai').catch((error) => {
                console.warn("Failed to fetch AI config.", error);
                return null;
            }),
        ]);

        if (webDavConfigRes?.ok) {
            setWebDavConfig(await webDavConfigRes.json());
        }

        if (aiConfigRes?.ok) {
            const remoteConfig = await aiConfigRes.json();
            const mergedConfig = mergeClientAIConfig(remoteConfig);
            setAiConfig(mergedConfig);
            saveLocalAIConfig(mergedConfig);
        }

        let hasCloudData = false;
        try {
          const bootstrapResult = await refreshBootstrap();
          setDashboardConfig(bootstrapResult.snapshot.dashboardConfig);
          if (bootstrapResult.remoteData) {
            const { links: mergedLinks, categories: nextCategories } = bootstrapResult.snapshot;
            cloudVersionRef.current = bootstrapResult.remoteData.version || 0;
            setLinks(mergedLinks);
            setCategories(nextCategories);
            cloudBaseRef.current = { links: mergedLinks, categories: nextCategories };
            localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify({ ...bootstrapResult.remoteData, links: mergedLinks, categories: nextCategories }));
            loadLinkIcons(mergedLinks);
            hasCloudData = true;
          }
        } catch (error) {
          if (error instanceof Error && error.message === 'AUTH_REQUIRED') {
            setAuthToken(false);
            setIsAuthOpen(true);
            setIsCheckingAuth(false);
            return;
          }
          console.warn('Failed to hydrate bootstrap data; keeping local snapshot.', error);
        }
        
        // 无论是否有云端数据，都尝试从KV空间加载搜索配置和网站配置
        let hasLoadedSearchConfig = false;
        const [searchConfigRes, websiteConfigRes] = await Promise.all([
            fetchWithTimeout('/api/storage?getConfig=search').catch((error) => {
                console.warn("Failed to fetch search config from KV.", error);
                return null;
            }),
            fetchWithTimeout('/api/storage?getConfig=website').catch((error) => {
                console.warn("Failed to fetch website config from KV.", error);
                return null;
            }),
        ]);

        if (searchConfigRes?.ok) {
            const searchConfigData = await searchConfigRes.json();
            // 检查搜索配置是否有效（包含必要的字段）
            if (searchConfigData && (searchConfigData.mode || searchConfigData.externalSources || searchConfigData.selectedSource)) {
                setSearchMode(searchConfigData.mode || 'external');
                setExternalSearchSources(searchConfigData.externalSources || []);
                // 加载已保存的选中搜索源
                if (searchConfigData.selectedSource) {
                    setSelectedSearchSource(searchConfigData.selectedSource);
                }
                localStorage.setItem(SEARCH_CONFIG_KEY, JSON.stringify(searchConfigData));
                hasLoadedSearchConfig = true;
            }
        }

        // 获取网站配置（包括密码过期时间设置）
        if (websiteConfigRes?.ok) {
            const websiteConfigData = await websiteConfigRes.json();
            if (websiteConfigData) {
                setSiteSettings(prev => {
                    const next = {
                        ...prev,
                        title: websiteConfigData.title || prev.title,
                        navTitle: websiteConfigData.navTitle || prev.navTitle,
                        favicon: websiteConfigData.favicon || prev.favicon,
                        cardStyle: websiteConfigData.cardStyle || prev.cardStyle,
                        passwordExpiryDays: websiteConfigData.passwordExpiryDays !== undefined ? websiteConfigData.passwordExpiryDays : prev.passwordExpiryDays
                    };
                    localStorage.setItem(SITE_SETTINGS_KEY, JSON.stringify(next));
                    return next;
                });
            }
        }
        
        if (!hasLoadedSearchConfig) {
            try {
                const savedSearchConfig = localStorage.getItem(SEARCH_CONFIG_KEY);
                if (savedSearchConfig) {
                    const searchConfigData = JSON.parse(savedSearchConfig) as SearchConfig;
                    if (searchConfigData && (searchConfigData.mode || searchConfigData.externalSources || searchConfigData.selectedSource)) {
                        setSearchMode(searchConfigData.mode || 'external');
                        setExternalSearchSources(searchConfigData.externalSources || []);
                        if (searchConfigData.selectedSource) {
                            setSelectedSearchSource(searchConfigData.selectedSource);
                        }
                        hasLoadedSearchConfig = true;
                    }
                }
            } catch (e) {
                console.warn("Failed to load local search config.", e);
            }
        }

        if (!hasLoadedSearchConfig) {
            setSearchMode('external');
            setExternalSearchSources(getDefaultSearchSources());
        }

        if (hasCloudData) {
            setIsLoadingSearchConfig(false);
            setIsCheckingAuth(false);
            return;
        }

        setIsLoadingSearchConfig(false);
        setIsCheckingAuth(false);
    };

    initData();
  }, []);

  // Update page title and favicon when site settings change
  useEffect(() => {
    if (siteSettings.title) {
      document.title = siteSettings.title;
    }
    
    if (siteSettings.favicon) {
      // Remove existing favicon links
      const existingFavicons = document.querySelectorAll('link[rel="icon"]');
      existingFavicons.forEach(favicon => favicon.remove());
      
      // Add new favicon
      const favicon = document.createElement('link');
      favicon.rel = 'icon';
      favicon.href = siteSettings.favicon;
      document.head.appendChild(favicon);
    }
  }, [siteSettings.title, siteSettings.favicon]);

  // Command Palette shortcut: Ctrl/Cmd+K
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        setIsPaletteOpen(prev => !prev);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  useEffect(() => {
    const handleOnline = () => {
      setIsOnline(true);
      void flushPendingSync();
    };
    const handleOffline = () => setIsOnline(false);
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, [authToken]);

  useEffect(() => {
    if (authToken && isOnline) void flushPendingSync();
  }, [authToken, isOnline]);

  useEffect(() => {
    void readPendingMutations().then(items => setPendingSyncCount(items.length)).catch(() => setPendingSyncCount(0));
  }, [authToken]);

  // 仅在用户开始搜索时加载拼音库，避免首屏为中文搜索能力支付额外体积。
  useEffect(() => {
    if (!searchQuery.trim() || pinyinReady) return;
    let active = true;
    preloadPinyin()
      .then(() => {
        if (active) setPinyinReady(true);
      })
      .catch(() => {
        // 原始标题、网址和标签搜索不依赖拼音库，加载失败时保持基础搜索可用。
      });
    return () => { active = false; };
  }, [searchQuery, pinyinReady]);

  const toggleTheme = () => {
    const newMode = !darkMode;
    setDarkMode(newMode);
    if (newMode) {
      document.documentElement.classList.add('dark');
      localStorage.setItem('theme', 'dark');
    } else {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('theme', 'light');
    }
  };

  // 视图模式切换处理函数
  const handleViewModeChange = (cardStyle: 'detailed' | 'simple') => {
    const newSiteSettings = { ...siteSettings, cardStyle };
    setSiteSettings(newSiteSettings);
    localStorage.setItem(SITE_SETTINGS_KEY, JSON.stringify(newSiteSettings));
  };

  // --- Batch Edit Functions ---
  const toggleBatchEditMode = () => {
    setIsBatchEditMode(!isBatchEditMode);
    setSelectedLinks(new Set()); // 退出批量编辑模式时清空选中项
  };

  const toggleLinkSelection = (linkId: string) => {
    setSelectedLinks(prev => {
      const newSet = new Set(prev);
      if (newSet.has(linkId)) {
        newSet.delete(linkId);
      } else {
        newSet.add(linkId);
      }
      return newSet;
    });
  };

  const handleBatchDelete = () => {
    if (!authToken) { setIsAuthOpen(true); return; }
    
    if (selectedLinks.size === 0) {
      alert('请先选择要删除的链接');
      return;
    }
    
    if (confirm(`确定要删除选中的 ${selectedLinks.size} 个链接吗？`)) {
      const newLinks = softDeleteLinks(links, [...selectedLinks]);
      updateData(newLinks, categories);
      setSelectedLinks(new Set());
      setIsBatchEditMode(false);
    }
  };

  const handleBatchMove = (targetCategoryId: string) => {
    if (!authToken) { setIsAuthOpen(true); return; }
    
    if (selectedLinks.size === 0) {
      alert('请先选择要移动的链接');
      return;
    }
    
    const newLinks = links.map(link => 
      selectedLinks.has(link.id) ? { ...link, categoryId: targetCategoryId } : link
    );
    updateData(newLinks, categories);
    setSelectedLinks(new Set());
    setIsBatchEditMode(false);
  };

  const handleBatchAction = (action: Parameters<typeof applyBulkAction>[2]) => {
    if (!authToken) { setIsAuthOpen(true); return; }
    if (selectedLinks.size === 0) { alert('请先选择要操作的链接'); return; }
    updateData(applyBulkAction(links, [...selectedLinks], action), categories);
    setSelectedLinks(new Set());
    setIsBatchEditMode(false);
  };

  const handleBatchAddTags = () => {
    const value = prompt('输入要添加的标签，多个标签用逗号分隔');
    const tags = value?.split(',').map(tag => tag.trim()).filter(Boolean) || [];
    if (tags.length > 0) handleBatchAction({ type: 'addTags', tags });
  };

  const handleSelectAll = () => {
    // 获取当前显示的所有链接ID
    const currentLinkIds = displayedLinks.map(link => link.id);
    
    // 如果已选中的链接数量等于当前显示的链接数量，则取消全选
    if (selectedLinks.size === currentLinkIds.length && currentLinkIds.every(id => selectedLinks.has(id))) {
      setSelectedLinks(new Set());
    } else {
      // 否则全选当前显示的所有链接
      setSelectedLinks(new Set(currentLinkIds));
    }
  };

  // --- Actions ---

  const handleLogin = async (password: string): Promise<boolean> => {
      try {
        const authResponse = await fetch('/api/auth', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ password })
        });

        if (authResponse.ok) {
            const authData = await authResponse.json();
            setAuthToken(true);
            setExtensionToken(authData.extensionToken || '');
            setIsAuthOpen(false);
            setSyncStatus('saved');

            try {
                const websiteConfigRes = await fetch('/api/storage?getConfig=website');
                if (websiteConfigRes.ok) {
                    const websiteConfigData = await websiteConfigRes.json();
                    if (websiteConfigData) {
                        setSiteSettings(prev => ({
                            ...prev,
                            title: websiteConfigData.title || prev.title,
                            navTitle: websiteConfigData.navTitle || prev.navTitle,
                            favicon: websiteConfigData.favicon || prev.favicon,
                            cardStyle: websiteConfigData.cardStyle || prev.cardStyle,
                            passwordExpiryDays: websiteConfigData.passwordExpiryDays !== undefined ? websiteConfigData.passwordExpiryDays : prev.passwordExpiryDays
                        }));
                    }
                }
            } catch (e) {
                console.warn("Failed to fetch website config after login.", e);
            }

            try {
                const webDavConfigRes = await fetch('/api/storage?getConfig=webdav');
                if (webDavConfigRes.ok) {
                    setWebDavConfig(await webDavConfigRes.json());
                }
            } catch (e) {
                console.warn("Failed to fetch WebDAV config after login.", e);
            }

            try {
                const res = await fetchWithTimeout('/api/storage');
                if (res.ok) {
                    const data = await res.json();
                    cloudVersionRef.current = typeof data.version === 'number' ? data.version : 0;
                    if (data.links && data.links.length > 0) {
                        const mergedLinks = mergeLocalVisitState(normalizeLinks(data.links));
                        const nextCategories = normalizeCategories(data.categories);
                        setLinks(mergedLinks);
                        setCategories(nextCategories);
                        cloudBaseRef.current = { links: mergedLinks, categories: nextCategories };
                        if (data.workspace) writeWorkspaceSnapshot(normalizeWorkspaceSnapshot(data.workspace), false);
                        localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify({ ...data, links: mergedLinks, categories: nextCategories }));
                        loadLinkIcons(mergedLinks);
                    } else {
                        localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify({ links, categories }));
                        syncToCloud(links, categories);
                        loadLinkIcons(links);
                    }
                }
            } catch (e) {
                console.warn("Failed to fetch data after login.", e);
                loadFromLocal();
                showToast('云端数据加载失败，已保留本地数据，未自动覆盖云端', { type: 'error' });
            }

            try {
                const aiConfigRes = await fetchWithTimeout('/api/storage?getConfig=ai');
                if (aiConfigRes.ok) {
                    const aiConfigData = await aiConfigRes.json();
                    if (aiConfigData && Object.keys(aiConfigData).length > 0) {
                        const mergedConfig = mergeClientAIConfig(aiConfigData);
                        setAiConfig(mergedConfig);
                        saveLocalAIConfig(mergedConfig);
                    }
                }
            } catch (e) {
                console.warn("Failed to fetch AI config after login.", e);
            }

            try {
                const dashboardConfigRes = await fetch('/api/storage?getConfig=dashboard');
                if (dashboardConfigRes.ok) {
                    const remoteConfig = normalizeDashboardConfig(await dashboardConfigRes.json());
                    setDashboardConfig(remoteConfig);
                    localStorage.setItem(DASHBOARD_CONFIG_KEY, JSON.stringify(remoteConfig));
                }
            } catch (e) {
                console.warn("Failed to fetch dashboard config after login.", e);
            }

            return true;
        }
        return false;
      } catch (e) {
          return false;
      }
  };

  const handleLogout = async () => {
      try {
          await fetch('/api/auth', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ action: 'logout' })
          });
      } catch (e) {
          console.warn('Failed to logout on server.', e);
      }
      setAuthToken(false);
      setExtensionToken('');
      setSyncStatus('idle');
      if (syncTimerRef.current !== null) {
        window.clearTimeout(syncTimerRef.current);
        syncTimerRef.current = null;
      }
      void replacePendingMutations([]);
      setPendingSyncCount(0);
      loadFromLocal();
  };

  const handleCategoryActionAuth = async (password: string): Promise<boolean> => {
    try {
      const authResponse = await fetch('/api/auth', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ password })
      });

      if (authResponse.ok) {
        const authData = await authResponse.json();
        setAuthToken(true);
        setExtensionToken(authData.extensionToken || '');
      }

      return authResponse.ok;
    } catch (error) {
      console.error('Category action auth error:', error);
      return false;
    }
  };

  // 打开分类操作验证弹窗
  const openCategoryActionAuth = (action: 'edit' | 'delete', categoryId: string, categoryName: string) => {
    setCategoryActionAuth({
      isOpen: true,
      action,
      categoryId,
      categoryName
    });
  };

  // 关闭分类操作验证弹窗
  const closeCategoryActionAuth = () => {
    setCategoryActionAuth({
      isOpen: false,
      action: 'edit',
      categoryId: '',
      categoryName: ''
    });
  };

  const handleCategoryActionVerified = () => {
    const { action, categoryId } = categoryActionAuth;
    if (action === 'edit') {
      setCategoryManagerEditId(categoryId);
      setIsCatManagerOpen(true);
      closeCategoryActionAuth();
      return;
    }

    if (window.confirm(`确定删除"${categoryActionAuth.categoryName}"分类吗？该分类下的书签将移动到"常用推荐"。`)) {
      handleDeleteCategory(categoryId);
    }
    closeCategoryActionAuth();
  };

  const handleImportConfirm = (newLinks: LinkItem[], newCategories: Category[]) => {
      // Merge categories: Avoid duplicate names/IDs
      const mergedCategories = [...categories];
      
      // 确保"常用推荐"分类始终存在
      if (!mergedCategories.some(c => c.id === 'common')) {
        mergedCategories.push({ id: 'common', name: '常用推荐', icon: 'Star' });
      }
      
      newCategories.forEach(nc => {
          if (!mergedCategories.some(c => c.id === nc.id || c.name === nc.name)) {
              mergedCategories.push(nc);
          }
      });

      const mergedLinks = [...links, ...newLinks];
      updateData(mergedLinks, mergedCategories);
      setIsImportModalOpen(false);
      alert(`成功导入 ${newLinks.length} 个新书签!`);
  };

  const handleAddLink = (data: Omit<LinkItem, 'id' | 'createdAt'>) => {
    if (!authToken) { setIsAuthOpen(true); return; }
    
    // 处理URL，确保有协议前缀
    let processedUrl = data.url;
    if (processedUrl && !processedUrl.startsWith('http://') && !processedUrl.startsWith('https://')) {
      processedUrl = 'https://' + processedUrl;
    }
    
    // 获取当前分类下的所有链接（不包括置顶链接）
    const categoryLinks = links.filter(link => 
      !link.pinned && (data.categoryId === 'all' || link.categoryId === data.categoryId)
    );
    
    // 计算新链接的order值，使其排在分类最后
    const maxOrder = categoryLinks.length > 0 
      ? Math.max(...categoryLinks.map(link => link.order || 0))
      : -1;
    
    const newLink: LinkItem = {
      ...data,
      url: processedUrl, // 使用处理后的URL
      id: Date.now().toString(),
      createdAt: Date.now(),
      order: maxOrder + 1, // 设置为当前分类的最大order值+1，确保排在最后
      // 如果是置顶链接，设置pinnedOrder为当前置顶链接数量
      pinnedOrder: data.pinned ? links.filter(l => l.pinned).length : undefined
    };
    
    // 将新链接插入到合适的位置，而不是直接放在开头
    // 如果是置顶链接，放在置顶链接区域的最后
    if (newLink.pinned) {
      const firstNonPinnedIndex = links.findIndex(link => !link.pinned);
      if (firstNonPinnedIndex === -1) {
        // 如果没有非置顶链接，直接添加到末尾
        updateData([...links, newLink], categories);
      } else {
        // 插入到非置顶链接之前
        const updatedLinks = [...links];
        updatedLinks.splice(firstNonPinnedIndex, 0, newLink);
        updateData(updatedLinks, categories);
      }
    } else {
      // 非置顶链接，按照order字段排序后插入
      const updatedLinks = [...links, newLink].sort((a, b) => {
        // 置顶链接始终排在前面
        if (a.pinned && !b.pinned) return -1;
        if (!a.pinned && b.pinned) return 1;
        
        // 同类型链接按照order排序
        const aOrder = a.order !== undefined ? a.order : a.createdAt;
        const bOrder = b.order !== undefined ? b.order : b.createdAt;
        return aOrder - bOrder;
      });
      updateData(updatedLinks, categories);
    }
    
    // Clear prefill if any
    setPrefillLink(undefined);
  };

  const handleEditLink = (data: Omit<LinkItem, 'id' | 'createdAt'>) => {
    if (!authToken) { setIsAuthOpen(true); return; }
    if (!editingLink) return;
    
    // 处理URL，确保有协议前缀
    let processedUrl = data.url;
    if (processedUrl && !processedUrl.startsWith('http://') && !processedUrl.startsWith('https://')) {
      processedUrl = 'https://' + processedUrl;
    }
    
    const updated = links.map(l => l.id === editingLink.id ? { ...l, ...data, url: processedUrl } : l);
    updateData(updated, categories);
    setEditingLink(undefined);
  };

  // 拖拽结束事件处理函数
  const handleDragEnd = (event: DragEndEvent) => {
    const { active, over } = event;

    if (over && active.id !== over.id) {
      // 获取当前分类下的所有链接（包括子分类）
      const subCategoryIds = categories.filter(c => c.parentId === selectedCategory).map(c => c.id);
      const categoryLinks = links.filter(link => 
        selectedCategory === 'all' || 
        link.categoryId === selectedCategory || 
        subCategoryIds.includes(link.categoryId)
      );
      
      // 找到被拖拽元素和目标元素的索引
      const activeIndex = categoryLinks.findIndex(link => link.id === active.id);
      const overIndex = categoryLinks.findIndex(link => link.id === over.id);
      
      if (activeIndex !== -1 && overIndex !== -1) {
        // 重新排序当前分类的链接
        const reorderedCategoryLinks = arrayMove<LinkItem>(categoryLinks, activeIndex, overIndex);
        
        // 更新所有链接的顺序
        const updatedLinks = links.map(link => {
          const reorderedIndex = reorderedCategoryLinks.findIndex(l => l.id === link.id);
          if (reorderedIndex !== -1) {
            return { ...link, order: reorderedIndex };
          }
          return link;
        });
        
        // 按照order字段重新排序
        updatedLinks.sort((a, b) => (a.order || 0) - (b.order || 0));
        
        updateData(updatedLinks, categories);
      }
    }
  };

  const openInspirationView = () => {
    setActiveView('inspiration');
    setSelectedCategory('all');
    setSearchQuery('');
    setQuickCaptureSeed(undefined);
    setSidebarOpen(false);
  };

  const openInspiration = (seed?: Partial<QuickCaptureInput>) => {
    openInspirationView();
    setQuickCaptureSeed(seed || { title: '', content: '', type: 'idea', tags: [] });
  };

  const openReadLater = () => {
    setActiveView('read-later');
    setSelectedCategory('all');
    setSearchQuery('');
    setSidebarOpen(false);
  };

  const openGithub = () => {
    setActiveView('github');
    setSelectedCategory('all');
    setSearchQuery('');
    setSidebarOpen(false);
  };

  const openInbox = () => {
    setActiveView('inbox');
    setSelectedCategory('all');
    setSearchQuery('');
    setSidebarOpen(false);
  };

  const openReadingWorkspace = () => {
    setActiveView('reading');
    setSelectedCategory('all');
    setSearchQuery('');
    setSidebarOpen(false);
  };

  const openUnifiedResult = (result: UnifiedSearchResult) => {
    setSearchQuery('');
    setUnifiedSearchTarget(result);
    if (result.kind === 'link') {
      openLinksView('all');
      setDetailsOrigin('right');
      setSelectedLinkId(result.id);
    } else if (result.kind === 'rss') openRssReader();
    else if (result.kind === 'inspiration') openInspirationView();
    else if (result.kind === 'read-later') openReadLater();
    else if (result.kind === 'github') openGithub();
    else if (result.kind === 'reading') openReadingWorkspace();
    else openInbox();
  };

  const handleQuickMoveLink = (linkId: string, direction: MoveDirection) => {
    if (!authToken) { setIsAuthOpen(true); return; }
    const target = links.find(link => link.id === linkId);
    if (!target || target.deletedAt) return;

    const isPinnedView = selectedCategory === 'all' && !searchQuery.trim();
    const categoryIds = selectedCategory === 'all'
      ? new Set<string>()
      : new Set([selectedCategory, ...categories.filter(category => category.parentId === selectedCategory).map(category => category.id)]);
    const scopedLinks = links
      .filter(link => !link.deletedAt && !isCategoryLocked(link.categoryId) && (isPinnedView ? link.pinned : categoryIds.has(link.categoryId)))
      .sort((a, b) => {
        if (isPinnedView) {
          const aOrder = a.pinnedOrder ?? a.createdAt;
          const bOrder = b.pinnedOrder ?? b.createdAt;
          return aOrder - bOrder;
        }
        const aOrder = a.order ?? a.createdAt;
        const bOrder = b.order ?? b.createdAt;
        return aOrder - bOrder;
      });
    const reordered = moveItem(scopedLinks, linkId, direction);
    if (reordered.every((link, index) => link.id === scopedLinks[index]?.id)) return;
    const orderMap = new Map(reordered.map((link, index) => [link.id, index]));
    const updated = links.map(link => {
      const nextOrder = orderMap.get(link.id);
      if (nextOrder === undefined) return link;
      return isPinnedView ? { ...link, pinnedOrder: nextOrder } : { ...link, order: nextOrder };
    });
    updateData(updated, categories);
  };

  // 置顶链接拖拽结束事件处理函数
  const handlePinnedDragEnd = (event: DragEndEvent) => {
    const { active, over } = event;

    if (over && active.id !== over.id) {
      // 获取所有置顶链接
      const pinnedLinksList = links.filter(link => link.pinned);
      
      // 找到被拖拽元素和目标元素的索引
      const activeIndex = pinnedLinksList.findIndex(link => link.id === active.id);
      const overIndex = pinnedLinksList.findIndex(link => link.id === over.id);
      
      if (activeIndex !== -1 && overIndex !== -1) {
        // 重新排序置顶链接
        const reorderedPinnedLinks = arrayMove<LinkItem>(pinnedLinksList, activeIndex, overIndex);
        
        // 创建一个映射，存储每个置顶链接的新pinnedOrder
        const pinnedOrderMap = new Map<string, number>();
        reorderedPinnedLinks.forEach((link, index) => {
          pinnedOrderMap.set(link.id, index);
        });
        
        // 只更新置顶链接的pinnedOrder，不改变任何链接的顺序
        const updatedLinks = links.map(link => {
          if (link.pinned) {
            return { 
              ...link, 
              pinnedOrder: pinnedOrderMap.get(link.id) 
            };
          }
          return link;
        });
        
        // 按照pinnedOrder重新排序整个链接数组，确保置顶链接的顺序正确
        // 同时保持非置顶链接的相对顺序不变
        updatedLinks.sort((a, b) => {
          // 如果都是置顶链接，按照pinnedOrder排序
          if (a.pinned && b.pinned) {
            return (a.pinnedOrder || 0) - (b.pinnedOrder || 0);
          }
          // 如果只有一个是置顶链接，置顶链接排在前面
          if (a.pinned) return -1;
          if (b.pinned) return 1;
          // 如果都不是置顶链接，保持原位置不变（按照order或createdAt排序）
          const aOrder = a.order !== undefined ? a.order : a.createdAt;
          const bOrder = b.order !== undefined ? b.order : b.createdAt;
          return bOrder - aOrder;
        });
        
        updateData(updatedLinks, categories);
      }
    }
  };

  // 开始排序
  const startSorting = (categoryId: string) => {
    setIsSortingMode(categoryId);
  };

  // 保存排序
  const saveSorting = () => {
    // 在保存排序时，确保将当前排序后的数据保存到服务器和本地存储
    updateData(links, categories);
    setIsSortingMode(null);
  };

  // 取消排序
  const cancelSorting = () => {
    setIsSortingMode(null);
  };

  // 保存置顶链接排序
  const savePinnedSorting = () => {
    // 在保存排序时，确保将当前排序后的数据保存到服务器和本地存储
    updateData(links, categories);
    setIsSortingPinned(false);
  };

  // 取消置顶链接排序
  const cancelPinnedSorting = () => {
    setIsSortingPinned(false);
  };

  // 设置dnd-kit的传感器
  const sensors = useSensors(
    useSensor(PointerSensor, {
      activationConstraint: {
        distance: 8, // 需要拖动8px才开始拖拽，避免误触
      },
    }),
    useSensor(KeyboardSensor, {
      coordinateGetter: sortableKeyboardCoordinates,
    })
  );

  const handleDeleteLink = (id: string) => {
    if (!authToken) { setIsAuthOpen(true); return; }
    if (confirm('确定删除此链接吗?')) {
      updateData(softDeleteLinks(links, [id]), categories);
    }
  };

  const togglePin = (id: string, e: React.MouseEvent) => {
      e.preventDefault();
      e.stopPropagation();
      if (!authToken) { setIsAuthOpen(true); return; }
      
      const linkToToggle = links.find(l => l.id === id);
      if (!linkToToggle) return;
      
      // 如果是设置为置顶，则设置pinnedOrder为当前置顶链接数量
      // 如果是取消置顶，则清除pinnedOrder
      const updated = links.map(l => {
        if (l.id === id) {
          const isPinned = !l.pinned;
          return { 
            ...l, 
            pinned: isPinned,
            pinnedOrder: isPinned ? links.filter(link => link.pinned).length : undefined
          };
        }
        return l;
      });
      
      updateData(updated, categories);
  };

  const handleSaveAIConfig = async (config: AIConfig, newSiteSettings?: any) => {
      const localConfig = saveLocalAIConfig(config);
      setAiConfig(localConfig);

      if (newSiteSettings) {
          setSiteSettings(newSiteSettings);
          localStorage.setItem(SITE_SETTINGS_KEY, JSON.stringify(newSiteSettings));
      }

      if (authToken) {
          try {
              const response = await fetch('/api/storage', {
                  method: 'POST',
                  headers: {
                      'Content-Type': 'application/json'
                  },
                  body: JSON.stringify({
                      saveConfig: 'ai',
                      config: localConfig
                  })
              });

              if (response.ok) {
                  const data = await response.json();
                  if (data.config) {
                      const mergedConfig = mergeClientAIConfig(data.config, localConfig);
                      setAiConfig(mergedConfig);
                       saveLocalAIConfig(mergedConfig);
                  }
              } else {
                  console.error('Failed to save AI config to KV:', response.statusText);
              }
          } catch (error) {
              console.error('Error saving AI config to KV:', error);
          }

          if (newSiteSettings) {
              try {
                  const response = await fetch('/api/storage', {
                      method: 'POST',
                      headers: {
                          'Content-Type': 'application/json'
                      },
                      body: JSON.stringify({
                          saveConfig: 'website',
                          config: newSiteSettings
                      })
                  });

                  if (!response.ok) {
                      console.error('Failed to save website config to KV:', response.statusText);
                  }
              } catch (error) {
                  console.error('Error saving website config to KV:', error);
              }
          }
      }
  };

  const handleRestoreAIConfig = async (config: AIConfig) => {
      const localConfig = saveLocalAIConfig(config);
      setAiConfig(localConfig);

      if (authToken) {
          try {
              const response = await fetch('/api/storage', {
                  method: 'POST',
                  headers: {
                      'Content-Type': 'application/json'
                  },
                  body: JSON.stringify({
                      saveConfig: 'ai',
                      config: localConfig
                  })
              });

              if (response.ok) {
                  const data = await response.json();
                  if (data.config) {
                      const mergedConfig = mergeClientAIConfig(data.config, localConfig);
                      setAiConfig(mergedConfig);
                       saveLocalAIConfig(mergedConfig);
                  }
              } else {
                  console.error('Failed to restore AI config to KV:', response.statusText);
              }
          } catch (error) {
              console.error('Error restoring AI config to KV:', error);
          }
      }
  };

  // --- Category Management & Security ---

  const handleCategoryClick = (cat: Category) => {
      // 检查当前分类或其父分类是否设置了密码且未解锁
      const getLockedAncestor = (category: Category): Category | null => {
          // 如果当前分类有密码且未解锁，返回当前分类
          if (category.password && !unlockedCategoryIds.has(category.id)) {
              return category;
          }
          // 如果有父分类，递归检查父分类
          if (category.parentId) {
              const parent = categories.find(c => c.id === category.parentId);
              if (parent) {
                  return getLockedAncestor(parent);
              }
          }
          return null;
      };

      const lockedAncestor = getLockedAncestor(cat);
      if (lockedAncestor) {
          setCatAuthModalData(lockedAncestor);
          setSidebarOpen(false);
          return;
      }
      
      openLinksView(cat.id);
  };

  const handleUnlockCategory = (catId: string) => {
      setUnlockedCategoryIds(prev => new Set(prev).add(catId));
      openLinksView(catId);
  };

  const handleUpdateCategories = (newCats: Category[]) => {
      if (!authToken) { setIsAuthOpen(true); return; }
      updateData(links, newCats);
  };

  const handleDeleteCategory = (catId: string, mode: 'migrate' | 'delete_all' = 'migrate', targetId: string = 'common') => {
      if (!authToken) { setIsAuthOpen(true); return; }
      
      // 找出所有要删除的分类ID（包括子分类）
      const idsToDelete = [catId];
      const children = categories.filter(c => c.parentId === catId);
      children.forEach(child => idsToDelete.push(child.id));

      let newCats = categories.filter(c => !idsToDelete.includes(c.id));
      
      let newLinks;
      if (mode === 'migrate') {
        // 迁移书签
        newLinks = links.map(l => idsToDelete.includes(l.categoryId) ? { ...l, categoryId: targetId } : l);
      } else {
        // 连同书签一起删除
        newLinks = links.filter(l => !idsToDelete.includes(l.categoryId));
      }
      
      updateData(newLinks, newCats);
  };

  // --- WebDAV Config ---
  const handleSaveWebDavConfig = async (config: WebDavConfig) => {
      setWebDavConfig(config);
      if (!authToken) return;

      try {
          const response = await fetch('/api/storage', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                  saveConfig: 'webdav',
                  config
              })
          });

          if (response.ok) {
              const data = await response.json();
              if (data.config) setWebDavConfig(data.config);
          } else {
              console.error('Failed to save WebDAV config to KV:', response.statusText);
          }
      } catch (error) {
          console.error('Error saving WebDAV config to KV:', error);
      }
  };

  // 搜索源选择弹出窗口状态
  const [showSearchSourcePopup, setShowSearchSourcePopup] = useState(false);
  const [hoveredSearchSource, setHoveredSearchSource] = useState<ExternalSearchSource | null>(null);
  const [selectedSearchSource, setSelectedSearchSource] = useState<ExternalSearchSource | null>(null);
  const [isIconHovered, setIsIconHovered] = useState(false);
  const [isPopupHovered, setIsPopupHovered] = useState(false);
  const hideTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  // 处理弹出窗口显示/隐藏逻辑
  useEffect(() => {
    if (isIconHovered || isPopupHovered) {
      // 如果图标或弹出窗口被悬停，清除隐藏定时器并显示弹出窗口
      if (hideTimeoutRef.current) {
        clearTimeout(hideTimeoutRef.current);
        hideTimeoutRef.current = null;
      }
      setShowSearchSourcePopup(true);
    } else {
      // 如果图标和弹出窗口都没有被悬停，设置一个延迟隐藏弹出窗口
      if (hideTimeoutRef.current) {
        clearTimeout(hideTimeoutRef.current);
      }
      hideTimeoutRef.current = setTimeout(() => {
        setShowSearchSourcePopup(false);
        setHoveredSearchSource(null);
      }, 100);
    }
    
    // 清理函数
    return () => {
      if (hideTimeoutRef.current) {
        clearTimeout(hideTimeoutRef.current);
      }
    };
  }, [isIconHovered, isPopupHovered]);

  // 处理搜索源选择
  const handleSearchSourceSelect = async (source: ExternalSearchSource) => {
    // 更新选中的搜索源
    setSelectedSearchSource(source);
    
    // 保存选中的搜索源到KV空间
    await handleSaveSearchConfig(externalSearchSources, searchMode, source);
    
    if (searchQuery.trim()) {
      const searchUrl = source.url.replace('{query}', encodeURIComponent(searchQuery));
      window.open(searchUrl, '_blank');
    }
    setShowSearchSourcePopup(false);
    setHoveredSearchSource(null);
  };

  const persistSearchConfig = async (sources: ExternalSearchSource[], mode: SearchMode, selectedSource?: ExternalSearchSource | null) => {
      const searchConfig: SearchConfig = {
          mode,
          externalSources: sources,
          selectedSource: selectedSource !== undefined ? selectedSource : selectedSearchSource
      };

      try {
          const response = await fetch('/api/storage', {
              method: 'POST',
              headers: {
                  'Content-Type': 'application/json'
              },
              body: JSON.stringify({
                  saveConfig: 'search',
                  config: searchConfig
              })
          });

          if (!response.ok) {
              console.error('Failed to save search config to KV:', response.statusText);
          }
      } catch (error) {
          console.error('Error saving search config to KV:', error);
      }
  };

  // --- Search Config ---
  const handleSaveSearchConfig = async (sources: ExternalSearchSource[], mode: SearchMode, selectedSource?: ExternalSearchSource | null) => {
      setExternalSearchSources(sources);
      setSearchMode(mode);
      if (selectedSource !== undefined) {
          setSelectedSearchSource(selectedSource);
      }
      await persistSearchConfig(sources, mode, selectedSource);
  };

  const handleSearchModeChange = (mode: SearchMode) => {
      const nextSources = mode === 'external' && externalSearchSources.length === 0 ? getDefaultSearchSources() : externalSearchSources;

      setSearchMode(mode);
      setExternalSearchSources(nextSources);
      persistSearchConfig(nextSources, mode);
  };

  const handleExternalSearch = () => {
      if (searchQuery.trim() && searchMode === 'external') {
          // 如果搜索源列表为空，自动加载默认搜索源
          if (externalSearchSources.length === 0) {
              const defaultSources: ExternalSearchSource[] = [
                  {
                      id: 'bing',
                      name: '必应',
                      url: 'https://www.bing.com/search?q={query}',
                      icon: 'Search',
                      enabled: true,
                      createdAt: Date.now()
                  },
                  {
                      id: 'google',
                      name: 'Google',
                      url: 'https://www.google.com/search?q={query}',
                      icon: 'Search',
                      enabled: true,
                      createdAt: Date.now()
                  },
                  {
                      id: 'baidu',
                      name: '百度',
                      url: 'https://www.baidu.com/s?wd={query}',
                      icon: 'Globe',
                      enabled: true,
                      createdAt: Date.now()
                  },
                  {
                      id: 'sogou',
                      name: '搜狗',
                      url: 'https://www.sogou.com/web?query={query}',
                      icon: 'Globe',
                      enabled: true,
                      createdAt: Date.now()
                  },
                  {
                      id: 'yandex',
                      name: 'Yandex',
                      url: 'https://yandex.com/search/?text={query}',
                      icon: 'Globe',
                      enabled: true,
                      createdAt: Date.now()
                  },
                  {
                      id: 'github',
                      name: 'GitHub',
                      url: 'https://github.com/search?q={query}',
                      icon: 'Github',
                      enabled: true,
                      createdAt: Date.now()
                  },
                  {
                      id: 'linuxdo',
                      name: 'Linux.do',
                      url: 'https://linux.do/search?q={query}',
                      icon: 'Terminal',
                      enabled: true,
                      createdAt: Date.now()
                  },
                  {
                      id: 'bilibili',
                      name: 'B站',
                      url: 'https://search.bilibili.com/all?keyword={query}',
                      icon: 'Play',
                      enabled: true,
                      createdAt: Date.now()
                  },
                  {
                      id: 'youtube',
                      name: 'YouTube',
                      url: 'https://www.youtube.com/results?search_query={query}',
                      icon: 'Video',
                      enabled: true,
                      createdAt: Date.now()
                  },
                  {
                      id: 'wikipedia',
                      name: '维基',
                      url: 'https://zh.wikipedia.org/wiki/Special:Search?search={query}',
                      icon: 'BookOpen',
                      enabled: true,
                      createdAt: Date.now()
                  }
              ];
              
              // 保存默认搜索源到状态和KV空间
              handleSaveSearchConfig(defaultSources, 'external');
              
              // 使用第一个默认搜索源立即执行搜索
              const searchUrl = defaultSources[0].url.replace('{query}', encodeURIComponent(searchQuery));
              window.open(searchUrl, '_blank');
              return;
          }
          
          // 如果有选中的搜索源，使用选中的搜索源；否则使用第一个启用的搜索源
          let source = selectedSearchSource;
          if (!source) {
              const enabledSources = externalSearchSources.filter(s => s.enabled);
              if (enabledSources.length > 0) {
                  source = enabledSources[0];
              }
          }
          
          if (source) {
              const searchUrl = source.url.replace('{query}', encodeURIComponent(searchQuery));
              window.open(searchUrl, '_blank');
          }
      }
  };

  const handleRestoreBackup = (restoredLinks: LinkItem[], restoredCategories: Category[], version?: number, restoredWorkbenchTools?: WorkbenchToolsState) => {
      if (typeof version === 'number') cloudVersionRef.current = version;
      updateData(restoredLinks, restoredCategories);
      if (restoredWorkbenchTools) updateWorkbenchTools(restoredWorkbenchTools);
      setIsBackupModalOpen(false);
  };

  const handleRestoreSearchConfig = (restoredSearchConfig: SearchConfig) => {
      handleSaveSearchConfig(restoredSearchConfig.externalSources, restoredSearchConfig.mode);
  };

  // --- Filtering & Memo ---

  // Helper to check if a category is "Locked" (Has password AND not unlocked, or its parent is locked)
  const isCategoryLocked = (catId: string): boolean => {
      const cat = categories.find(c => c.id === catId);
      if (!cat) return false;
      
      // 检查当前分类是否锁定
      if (cat.password && !unlockedCategoryIds.has(catId)) return true;
      
      // 如果有父分类，递归检查父分类是否锁定
      if (cat.parentId) {
          return isCategoryLocked(cat.parentId);
      }
      
      return false;
  };

  const pinnedLinks = useMemo(() => {
      // Don't show pinned links if they belong to a locked category
       const filteredPinnedLinks = links.filter(l => l.pinned && !l.deletedAt && !isCategoryLocked(l.categoryId));
      // 按照pinnedOrder字段排序，如果没有pinnedOrder字段则按创建时间排序
      return filteredPinnedLinks.sort((a, b) => {
        // 如果有pinnedOrder字段，则使用pinnedOrder排序
        if (a.pinnedOrder !== undefined && b.pinnedOrder !== undefined) {
          return a.pinnedOrder - b.pinnedOrder;
        }
        // 如果只有一个有pinnedOrder字段，有pinnedOrder的排在前面
        if (a.pinnedOrder !== undefined) return -1;
        if (b.pinnedOrder !== undefined) return 1;
        // 如果都没有pinnedOrder字段，则按创建时间排序
        return a.createdAt - b.createdAt;
      });
  }, [links, categories, unlockedCategoryIds]);

  const inboxLinks = useMemo(() => links.filter(l => l.categoryId === INBOX_ID && !l.deletedAt && !isCategoryLocked(l.categoryId)), [links, categories, unlockedCategoryIds]);

  const advancedFilterActive = useMemo(() => Object.values(advancedFilters).some(value => value !== undefined && value !== '' && value !== false), [advancedFilters]);

  const allTags = useMemo(() => {
    return Array.from(new Set(links.flatMap(link => link.tags || []))).sort((a, b) => a.localeCompare(b));
  }, [links]);

  const searchIndex = useMemo(() => buildSearchIndex(links), [links]);

  const matchesAdvancedFilters = (link: LinkItem) => {
    if (advancedFilters.status && link.status !== advancedFilters.status) return false;
    if (advancedFilters.tag && !link.tags?.includes(String(advancedFilters.tag))) return false;
    if (advancedFilters.hasNote && !link.note?.trim()) return false;
    if (advancedFilters.untagged && (link.tags || []).length > 0) return false;
    if (advancedFilters.broken && link.health?.status !== 'broken') return false;
    return true;
  };

  const sortByManualOrder = (items: LinkItem[]) => [...items].sort((a, b) => {
    const aOrder = a.order !== undefined ? a.order : a.createdAt;
    const bOrder = b.order !== undefined ? b.order : b.createdAt;
    return aOrder - bOrder;
  });

  const displayedLinks = useMemo(() => {
    const parsedQuery = parseSearchQuery(searchQuery);
    const hasSearch = searchQuery.trim().length > 0;
    let result = links.filter(l => !isCategoryLocked(l.categoryId) && !l.deletedAt);

    if (hasSearch) {
       result = result.filter(l => matchesFilters(l, parsedQuery, categories) && matchesQuery(l, parsedQuery.text, searchIndex.get(l.id)?.text));
    }

    if (advancedFilterActive) {
      result = result.filter(matchesAdvancedFilters);
    }

    if (selectedCategory !== 'all') {
      const subCategoryIds = categories.filter(c => c.parentId === selectedCategory).map(c => c.id);
      result = result.filter(l => l.categoryId === selectedCategory || subCategoryIds.includes(l.categoryId));
    }

    return hasSearch ? sortByRelevance(result, parsedQuery.text || searchQuery) : sortByManualOrder(result);
  }, [links, selectedCategory, searchQuery, pinyinReady, advancedFilters, advancedFilterActive, categories, unlockedCategoryIds, searchIndex]);

  // 计算其他目录的搜索结果
  const otherCategoryResults = useMemo<Record<string, LinkItem[]>>(() => {
    if ((!searchQuery.trim() && !advancedFilterActive) || selectedCategory === 'all') {
      return {};
    }

    const parsedQuery = parseSearchQuery(searchQuery);
    const currentCategoryIds = new Set([
      selectedCategory,
      ...categories.filter(c => c.parentId === selectedCategory).map(c => c.id),
    ]);

    const otherLinks = links.filter(link => {
      if (currentCategoryIds.has(link.categoryId)) return false;
      if (isCategoryLocked(link.categoryId) || link.deletedAt) return false;
       if (searchQuery.trim() && (!matchesFilters(link, parsedQuery, categories) || !matchesQuery(link, parsedQuery.text, searchIndex.get(link.id)?.text))) return false;
      return !advancedFilterActive || matchesAdvancedFilters(link);
    });

    return otherLinks.reduce((acc, link) => {
      if (!acc[link.categoryId]) acc[link.categoryId] = [];
      acc[link.categoryId].push(link);
      acc[link.categoryId] = searchQuery.trim() ? sortByRelevance(acc[link.categoryId], parsedQuery.text || searchQuery) : sortByManualOrder(acc[link.categoryId]);
      return acc;
    }, {} as Record<string, LinkItem[]>);
  }, [links, selectedCategory, searchQuery, pinyinReady, advancedFilters, advancedFilterActive, categories, unlockedCategoryIds, searchIndex]);

  // “置顶网站”是独立的默认入口，不再把未置顶链接混在页面下方；搜索时仍允许跨目录查找。
  const showMainLinksGrid = activeView === 'links' && (selectedCategory !== 'all' || Boolean(searchQuery.trim()));

  const handleAiOrganizeCurrent = async () => {
    const current = inboxLinks[organizeIndex];
    if (!current || isAiOrganizing) return;
    if (!aiConfig.hasApiKey && !aiConfig.apiKey) {
      alert('请先在设置里配置并保存 AI API Key');
      setIsSettingsModalOpen(true);
      return;
    }

    setIsAiOrganizing(true);
    try {
      const { suggestCategory } = await import('./services/geminiService');
      const availableCategories = categories
        .filter(c => c.id !== INBOX_ID && !c.password && c.id !== 'all')
        .map(c => ({ id: c.id, name: c.name }));
      const categoryId = await suggestCategory(current.title, current.url, availableCategories, aiConfig);
      const targetCategoryId = categoryId && categories.some(c => c.id === categoryId && c.id !== INBOX_ID) ? categoryId : 'common';
      const nextLinks = links.map(l => l.id === current.id ? { ...l, categoryId: targetCategoryId, status: 'read' as const, updatedAt: Date.now() } : l);
      updateData(nextLinks, categories);
      showToast(`已整理到 ${categories.find(c => c.id === targetCategoryId)?.name || '常用推荐'}`, { type: 'success' });
      if (organizeIndex < inboxLinks.length - 1) setOrganizeIndex(i => i + 1);
      else { setIsOrganizeMode(false); setOrganizeIndex(0); }
    } catch (e) {
      const message = e instanceof Error ? e.message : 'AI 整理失败';
      alert(`AI 整理失败：${message}`);
    } finally {
      setIsAiOrganizing(false);
    }
  };

  // --- Render Components ---

  // 创建可排序的链接卡片组件
  const SortableLinkCard = ({ link }: { link: LinkItem }) => {
    const {
      attributes,
      listeners,
      setNodeRef,
      transform,
      transition,
      isDragging,
    } = useSortable({ id: link.id });
    
    // 根据视图模式决定卡片样式
    const isDetailedView = siteSettings.cardStyle === 'detailed';
    
    const style = {
      transform: CSS.Transform.toString(transform),
      transition: isDragging ? 'none' : transition,
      opacity: isDragging ? 0.5 : 1,
      zIndex: isDragging ? 1000 : 'auto',
    };

    return (
      <div
        ref={setNodeRef}
        style={style}
        className={`group relative transition-all duration-200 cursor-grab active:cursor-grabbing min-w-0 max-w-full overflow-hidden hover:shadow-lg hover:shadow-green-100/50 dark:hover:shadow-green-900/20 ${
          isSortingMode || isSortingPinned
            ? 'bg-green-20 dark:bg-green-900/30 border-green-200 dark:border-green-800' 
            : 'bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700'
        } ${isDragging ? 'shadow-2xl scale-105' : ''} ${
          isDetailedView 
            ? 'flex flex-col rounded-2xl border shadow-sm p-4 min-h-[100px] hover:border-green-400 dark:hover:border-green-500' 
            : 'flex items-center rounded-xl border shadow-sm hover:border-green-300 dark:hover:border-green-600'
        }`}
        {...attributes}
        {...listeners}
      >
        {/* 链接内容 - 移除a标签，改为div防止点击跳转 */}
        <div className={`flex flex-1 min-w-0 overflow-hidden ${
          isDetailedView ? 'flex-col' : 'items-center gap-3'
        }`}>
          {/* 第一行：图标和标题水平排列 */}
          <div className={`flex items-center gap-3 mb-2 ${
            isDetailedView ? '' : 'w-full'
          }`}>
            {/* Icon */}
            <div className={`text-blue-600 dark:text-blue-400 flex items-center justify-center text-sm font-bold uppercase shrink-0 ${
              isDetailedView ? 'w-8 h-8 rounded-xl bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-700 dark:to-slate-800' : 'w-8 h-8 rounded-lg bg-slate-50 dark:bg-slate-700'
            }`}>
                {link.icon ? <img src={link.icon} alt="" className="w-5 h-5"/> : link.title.charAt(0)}
            </div>
            
            {/* 标题 */}
            <h3 className={`text-slate-900 dark:text-slate-100 truncate overflow-hidden text-ellipsis ${
              isDetailedView ? 'text-base' : 'text-sm font-medium text-slate-800 dark:text-slate-200'
            }`} title={link.title}>
                {link.title}
            </h3>
          </div>
          
          {/* 第二行：描述文字 */}
             {isDetailedView && link.description && (
               <p className="text-sm text-slate-600 dark:text-slate-400 leading-relaxed line-clamp-2">
                 {link.description}
               </p>
             )}
        </div>
      </div>
    );
  };

  const renderLinkCard = (link: LinkItem) => {
    const isSelected = selectedLinks.has(link.id);
    
    // 检查是否在有二级分类的一级分类页面下，且该站点未归属到二级分类
    const isUnassignedHighlight = selectedCategory !== 'all' && 
                                 !categories.find(c => c.id === selectedCategory)?.parentId && 
                                 link.categoryId === selectedCategory && 
                                 categories.some(c => c.parentId === selectedCategory);

    // 根据视图模式决定卡片样式
    const isDetailedView = siteSettings.cardStyle === 'detailed';
    
    return (
      <PinnedSiteCard
        key={link.id}
        className={`group relative transition-all duration-200 hover:shadow-lg hover:shadow-blue-100/50 dark:hover:shadow-blue-900/20 ${
          isSelected 
            ? 'bg-red-50 dark:bg-red-900/30 border-red-200 dark:border-red-800' 
            : isUnassignedHighlight
              ? 'bg-amber-50 dark:bg-amber-900/20 border-amber-200 dark:border-amber-800/50 hover:bg-amber-100 dark:hover:bg-amber-900/30'
              : 'bg-white dark:bg-slate-800 hover:bg-blue-50 dark:hover:bg-blue-900/20 border-slate-200 dark:border-slate-700'
        } ${isBatchEditMode ? 'cursor-pointer' : ''} ${
          isDetailedView 
            ? 'flex flex-col rounded-2xl border shadow-sm p-4 min-h-[100px] hover:border-blue-400 dark:hover:border-blue-500' 
            : 'flex items-center justify-between rounded-xl border shadow-sm p-3 hover:border-blue-300 dark:hover:border-blue-600'
        }`}
        onClick={() => isBatchEditMode && toggleLinkSelection(link.id)}
        onContextMenu={(e) => handleContextMenu(e, link)}
      >
        {/* 链接内容 - 在批量编辑模式下不使用a标签 */}
        {isBatchEditMode ? (
          <div className={`flex flex-1 min-w-0 overflow-hidden h-full ${
            isDetailedView ? 'flex-col' : 'items-center'
          }`}>
            {/* 第一行：图标和标题水平排列 */}
            <div className={`flex items-center gap-3 w-full`}>
              {/* Icon */}
              <div className={`text-blue-600 dark:text-blue-400 flex items-center justify-center text-sm font-bold uppercase shrink-0 ${
                isDetailedView ? 'w-8 h-8 rounded-xl bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-700 dark:to-slate-800' : 'w-8 h-8 rounded-lg bg-slate-50 dark:bg-slate-700'
              }`}>
                  {link.icon ? <img src={link.icon} alt="" className="w-5 h-5"/> : link.title.charAt(0)}
              </div>
              
              {/* 标题 */}
              <h3 className={`text-slate-900 dark:text-slate-100 truncate overflow-hidden text-ellipsis ${
                isDetailedView ? 'text-base' : 'text-sm font-medium text-slate-800 dark:text-slate-200'
              }`} title={link.title}>
                  {link.title}
              </h3>
            </div>
            
            {/* 第二行：描述文字 */}
            {isDetailedView && link.description && (
              <p className="text-sm text-slate-600 dark:text-slate-400 leading-relaxed line-clamp-2">
                {link.description}
              </p>
            )}
          </div>
        ) : (
          <a
            href={link.url}
            target="_blank"
            rel="noopener noreferrer"
            className={`flex flex-1 min-w-0 overflow-hidden h-full ${
              isDetailedView ? 'flex-col' : 'items-center'
            }`}
            onClick={() => recordVisit(link.id)}
            title={isDetailedView ? link.url : (link.description || link.url)} // 详情版视图只显示URL作为tooltip
          >
            {/* 第一行：图标和标题水平排列 */}
            <div className={`flex items-center gap-3 w-full`}>
              {/* Icon */}
              <div className={`text-blue-600 dark:text-blue-400 flex items-center justify-center text-sm font-bold uppercase shrink-0 ${
                isDetailedView ? 'w-8 h-8 rounded-xl bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-700 dark:to-slate-800' : 'w-8 h-8 rounded-lg bg-slate-50 dark:bg-slate-700'
              }`}>
                  {link.icon ? <img src={link.icon} alt="" className="w-5 h-5"/> : link.title.charAt(0)}
              </div>
              
              {/* 标题 */}
                <h3 className={`text-slate-800 dark:text-slate-200 truncate whitespace-nowrap overflow-hidden text-ellipsis group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors ${
                  isDetailedView ? 'text-base' : 'text-sm font-medium'
                }`} title={link.title}>
                    {link.title}
                </h3>
            </div>
            
            {/* 第二行：描述文字 */}
              {isDetailedView && link.description && (
                <p className="text-sm text-slate-600 dark:text-slate-400 leading-relaxed line-clamp-2">
                  {link.description}
                </p>
              )}
            {!isDetailedView && link.description && (
              <div className="tooltip-custom absolute left-0 -top-8 w-max max-w-[200px] bg-black text-white text-xs p-2 rounded opacity-0 invisible group-hover:visible group-hover:opacity-100 transition-all z-20 pointer-events-none truncate">
                {link.description}
              </div>
            )}
          </a>
        )}

        {/* Hover Actions (Absolute Right) - 在批量编辑模式下隐藏 */}
        {!isBatchEditMode && (
          <div className={`flex items-center justify-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity bg-blue-50 dark:bg-blue-900/20 backdrop-blur-sm rounded-md p-1 absolute ${
            isDetailedView ? 'top-3 right-3' : 'top-1/2 -translate-y-1/2 right-2'
          }`}>
              <button
                  onClick={(e) => { e.preventDefault(); e.stopPropagation(); setDetailsOrigin(window.matchMedia('(max-width: 1023px)').matches ? 'bottom' : 'right'); setSelectedLinkId(link.id); }}
                  className="p-1 text-slate-400 hover:text-blue-500 hover:bg-slate-100 dark:hover:bg-slate-700 rounded-md"
                  title="详情"
              >
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                      <path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"/><path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"/>
                  </svg>
              </button>
              <button
                  onClick={(e) => { e.preventDefault(); e.stopPropagation(); setEditingLink(link); setIsModalOpen(true); }}
                  className="p-1 text-slate-400 hover:text-blue-500 hover:bg-slate-100 dark:hover:bg-slate-700 rounded-md"
                  title="编辑"
              >
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                      <path d="M12 15.5A3.5 3.5 0 0 1 8.5 12A3.5 3.5 0 0 1 12 8.5a3.5 3.5 0 0 1 3.5 3.5a3.5 3.5 0 0 1-3.5 3.5m7.43-2.53c.04-.32.07-.64.07-.97c0-.33-.03-.65-.07-.97l2.11-1.63c.19-.15.24-.42.12-.64l-2-3.46c-.12-.22-.39-.3-.61-.22l-2.49 1c-.52-.39-1.06-.73-1.69-.98l-.37-2.65A.506.506 0 0 0 14 2h-4c-.25 0-.46.18-.5.42l-.37 2.65c-.63.25-1.17.59-1.69.98l-2.49-1c-.22-.08-.49 0-.61.22l-2 3.46c-.13.22-.07.49.12.64L4.57 11c-.04.32-.07.64-.07.97c0 .33.03.65.07.97l-2.11 1.63c-.19.15-.24.42-.12.64l2 3.46c.12.22.39.3.61.22l2.49-1c.52.39 1.06.73 1.69.98l.37 2.65c.04.24.25.42.5.42h4c.25 0 .46-.18.5-.42l.37-2.65c.63-.25 1.17-.59 1.69-.98l2.49 1c.22.08.49 0 .61-.22l2-3.46c.13-.22.07-.49-.12-.64l-2.11-1.63Z" fill="currentColor"/>
                  </svg>
              </button>
          </div>
        )}
      </PinnedSiteCard>
    );
  };

  return (
    <React.Suspense fallback={null}>
      <AppShell>
        <div data-ui-skin="command-desk" data-redesign-skin="cloudnav-redesign" data-command-v2="true" className="cloudnav-desktop-frame cloudnav-command-desk cloudnav-command-v2 cloudnav-redesign-root flex h-screen overflow-hidden text-slate-900 dark:text-slate-50">
      {/* 认证遮罩层 - 当需要认证时显示 */}
      {requiresAuth && !authToken && (
        <div className="fixed inset-0 z-50 bg-white dark:bg-slate-900 flex items-center justify-center">
          <div className="w-full max-w-md p-6">
            <div className="text-center mb-8">
              <div className="mx-auto w-16 h-16 bg-blue-100 dark:bg-blue-900/30 rounded-full flex items-center justify-center mb-4">
                <Lock className="w-8 h-8 text-blue-600 dark:text-blue-400" />
              </div>
              <h1 className="text-2xl font-bold text-slate-900 dark:text-slate-50 mb-2">
                需要身份验证
              </h1>
              <p className="text-slate-600 dark:text-slate-400">
                此导航页面设置了访问密码，请输入密码以继续访问
              </p>
            </div>
            <AuthModal isOpen={true} onLogin={handleLogin} />
          </div>
        </div>
      )}
      
      {/* 主要内容 - 只有在不需要认证或已认证时显示 */}
      {(!requiresAuth || authToken) && (
        <>
          <AuthModal isOpen={isAuthOpen} onLogin={handleLogin} />
      
      {catAuthModalData && (
        <CategoryAuthModal
          isOpen={true}
          category={catAuthModalData}
          onClose={() => setCatAuthModalData(null)}
          onUnlock={handleUnlockCategory}
        />
      )}

      {isCatManagerOpen && (
        <CategoryManagerModal
          isOpen={true}
          onClose={() => { setIsCatManagerOpen(false); setCategoryManagerEditId(''); }}
          categories={categories}
          onUpdateCategories={handleUpdateCategories}
          onDeleteCategory={handleDeleteCategory}
          onVerifyPassword={handleCategoryActionAuth}
          initialEditId={categoryManagerEditId}
        />
      )}

      {isBackupModalOpen && (
        <BackupModal
          isOpen={true}
          onClose={() => setIsBackupModalOpen(false)}
          links={links}
          categories={categories}
          onRestore={handleRestoreBackup}
          webDavConfig={webDavConfig}
          onSaveWebDavConfig={handleSaveWebDavConfig}
          searchConfig={{ mode: searchMode, externalSources: externalSearchSources }}
           onRestoreSearchConfig={handleRestoreSearchConfig}
           aiConfig={aiConfig}
           onRestoreAIConfig={handleRestoreAIConfig}
           workbenchTools={workbenchTools}
           dataVersion={cloudVersionRef.current}
        />
      )}

      {isImportModalOpen && (
        <ModalErrorBoundary onClose={() => setIsImportModalOpen(false)}>
          <ImportModal
            isOpen={true}
            onClose={() => setIsImportModalOpen(false)}
            existingLinks={links}
            categories={categories}
            onImport={handleImportConfirm}
            onImportSearchConfig={handleRestoreSearchConfig}
            onImportAIConfig={handleRestoreAIConfig}
            onImportWorkbenchTools={updateWorkbenchTools}
          />
        </ModalErrorBoundary>
      )}

      {isSettingsModalOpen && (
        <SettingsModal
          isOpen={true}
          onClose={() => { setIsSettingsModalOpen(false); setAiSettingsCategoryId(''); setAiSettingsAction(''); setSettingsInitialTab(undefined); }}
          config={aiConfig}
          siteSettings={siteSettings}
          onSave={handleSaveAIConfig}
          links={links}
          categories={categories}
          onUpdateLinks={(newLinks) => updateData(newLinks, categories)}
          onUpdateCategories={(newCats) => updateData(links, newCats)}
          onUpdateData={(nextLinks, nextCats) => updateData(nextLinks, nextCats)}
          onEditLink={(link) => {
            setIsSettingsModalOpen(false);
            setSettingsInitialTab(undefined);
            setEditingLink(link);
            setIsModalOpen(true);
          }}
          authToken={authToken}
          extensionToken={extensionToken}
          initialAICategoryId={aiSettingsCategoryId}
          initialAIAction={aiSettingsAction || undefined}
          initialTab={settingsInitialTab}
        />
      )}

      {isSearchConfigModalOpen && (
        <SearchConfigModal
          isOpen={true}
          onClose={() => setIsSearchConfigModalOpen(false)}
          sources={externalSearchSources}
          onSave={(sources) => handleSaveSearchConfig(sources, searchMode)}
        />
      )}

      {isPaletteOpen && (
        <CommandPalette
          isOpen={true}
          onClose={() => setIsPaletteOpen(false)}
          links={links}
          categories={categories}
          actions={[
          { id: 'add-link', title: '添加链接', description: '新建一个网站卡片', keywords: ['add', 'new', '添加', '链接'], icon: <Plus size={14} />, group: 'action', run: () => { if (!authToken) setIsAuthOpen(true); else { setEditingLink(undefined); setIsModalOpen(true); } } },
          { id: 'settings', title: '打开设置', description: '网站、AI 与扩展工具设置', keywords: ['settings', '设置', 'ai'], icon: <Settings size={14} />, group: 'action', run: () => { setSettingsInitialTab(undefined); setIsSettingsModalOpen(true); } },
          { id: 'duplicates', title: '检测重复网址', description: '扫描并清理重复书签', keywords: ['duplicate', '重复', '去重', '网址'], icon: <CopyCheck size={14} />, group: 'action', run: () => { if (!authToken) setIsAuthOpen(true); else { setSettingsInitialTab('duplicates'); setIsSettingsModalOpen(true); } } },
          { id: 'health', title: '检测无法访问网站', description: '批量健康检测并清理失效链接', keywords: ['health', 'broken', '失效', '无法访问', '死链', '清理'], icon: <AlertCircle size={14} />, group: 'action', run: () => { if (!authToken) setIsAuthOpen(true); else { setSettingsInitialTab('health'); setIsSettingsModalOpen(true); } } },
          { id: 'recycle', title: '打开回收站', description: '恢复或永久删除已移除的链接', keywords: ['recycle', 'trash', '回收站', '恢复'], icon: <Trash2 size={14} />, group: 'action', run: () => { if (!authToken) setIsAuthOpen(true); else { setSettingsInitialTab('recycle'); setIsSettingsModalOpen(true); } } },
          { id: 'backup', title: '备份与恢复', description: 'WebDAV 与本地导出', keywords: ['backup', '备份', '恢复'], icon: <Cloud size={14} />, group: 'action', run: () => setIsBackupModalOpen(true) },
          { id: 'import', title: '导入书签', description: '导入 HTML 或 JSON 备份', keywords: ['import', '导入', '书签'], icon: <Upload size={14} />, group: 'action', run: () => setIsImportModalOpen(true) },
           { id: 'organize', title: '整理待处理链接', description: `${inboxLinks.length} 个待整理`, keywords: ['organize', 'inbox', '整理', '待整理'], icon: <CheckSquare size={14} />, group: 'action', run: () => { if (inboxLinks.length > 0) { openLinksView(INBOX_ID); setOrganizeIndex(0); setIsOrganizeMode(true); } } },
            { id: 'rss', title: '打开 RSS 资讯', description: '阅读每日热点与订阅源', keywords: ['rss', 'news', '资讯', '订阅', '热点'], icon: <ExternalLink size={14} />, group: 'action', run: openRssReader },
            { id: 'unified-inbox', title: '打开统一收件箱', description: '集中处理资讯、灵感和稍后阅读', keywords: ['inbox', '收件箱', '待处理', '信息流'], icon: <CheckSquare size={14} />, group: 'action', run: openInbox },
            { id: 'capture', title: '快速记录灵感', description: '把想法、摘录或网页保存到灵感库', keywords: ['capture', 'idea', '灵感', '记录', '笔记'], icon: <Plus size={14} />, group: 'action', run: () => openInspiration() },
           { id: 'read-later', title: '打开稍后阅读', description: '查看待阅读和已归档内容', keywords: ['later', '稍后', '阅读', '未读'], icon: <CheckSquare size={14} />, group: 'action', run: openReadLater },
           { id: 'reading-workspace', title: '打开阅读台', description: '统一阅读、批注、高亮和离线内容', keywords: ['reading', 'reader', '阅读台', '高亮', '批注', '离线'], icon: <FileText size={14} />, group: 'action', run: openReadingWorkspace },
           { id: 'github', title: '打开 GitHub 追踪', description: '查看正在关注的仓库', keywords: ['github', '仓库', '项目', '追踪'], icon: <Github size={14} />, group: 'action', run: openGithub },
          { id: 'theme', title: darkMode ? '切换到浅色模式' : '切换到深色模式', keywords: ['theme', 'dark', 'light', '主题'], icon: darkMode ? <Sun size={14} /> : <Moon size={14} />, group: 'action', run: toggleTheme },
        ]}
         onOpenLink={(link) => { void openWebsiteWithSummary(link); }}
        onSelectCategory={(categoryId) => openLinksView(categoryId)}
          onOpenInbox={() => { openLinksView(INBOX_ID); setOrganizeIndex(0); setIsOrganizeMode(true); }}
        />
      )}

      {/* Sidebar Mobile Overlay */}
      {sidebarOpen && (
        <div 
          className="fixed inset-0 z-20 bg-black/50 lg:hidden backdrop-blur-sm"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside 
        className={`
          cloudnav-desktop-sidebar fixed lg:static inset-y-0 left-0 z-50 w-64 transform transition-transform duration-300 ease-in-out
          bg-white dark:bg-slate-800 border-r border-slate-200 dark:border-slate-700 flex flex-col
          ${sidebarOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}
        `}
      >
        {/* Logo */}
        <div className="h-16 flex items-center px-6 border-b border-slate-100 dark:border-slate-700 shrink-0">
            <span className="text-xl font-bold bg-gradient-to-r from-blue-500 to-purple-500 bg-clip-text text-transparent">
              {siteSettings.navTitle || 'CloudNav'}
            </span>
        </div>

        {/* Categories List */}
        <div 
          className="flex-1 overflow-y-auto py-4 space-y-1 scrollbar-hide"
          onScroll={() => setHoveredCategory(null)}
        >
            <div className="px-4 space-y-1">
              <button
                onClick={openWorkbench}
                className={`command-desk-nav-item w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all ${
                  activeView === 'workbench'
                    ? 'cloudnav-desktop-active bg-blue-50 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 font-medium'
                    : 'text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-700'
                }`}
              >
                <div className="p-1"><Icon name="Zap" size={18} /></div>
                <span>工作台</span>
              </button>
              <button
                onClick={() => openLinksView('all')}
                className={`command-desk-nav-item w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all ${
                  activeView === 'links' && selectedCategory === 'all'
                    ? 'cloudnav-desktop-active bg-blue-50 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 font-medium'
                    : 'text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-700'
                }`}
              >
                <div className="p-1"><Icon name="LayoutGrid" size={18} /></div>
                <span>置顶网站</span>
              </button>
              <button
                onClick={openRssReader}
                className={`command-desk-nav-item w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all ${
                  activeView === 'rss'
                    ? 'cloudnav-desktop-active bg-blue-50 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 font-medium'
                    : 'text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-700'
                }`}
              >
                <div className="p-1"><Icon name="Rss" size={18} /></div>
                <span>RSS资讯</span>
              </button>
              <button
                onClick={openInbox}
                className={`command-desk-nav-item w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all ${activeView === 'inbox' ? 'cloudnav-desktop-active bg-blue-50 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 font-medium' : 'text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-700'}`}
              ><div className="p-1"><Icon name="Inbox" size={18} /></div><span>统一收件箱</span></button>
              <button
                onClick={openReadingWorkspace}
                className={`command-desk-nav-item w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all ${activeView === 'reading' ? 'cloudnav-desktop-active bg-blue-50 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 font-medium' : 'text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-700'}`}
              ><div className="p-1"><Icon name="BookOpen" size={18} /></div><span>阅读台</span></button>
              <button
                onClick={openInspirationView}
                className={`command-desk-nav-item w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all ${activeView === 'inspiration' ? 'cloudnav-desktop-active bg-blue-50 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 font-medium' : 'text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-700'}`}
              ><div className="p-1"><Icon name="Lightbulb" size={18} /></div><span>灵感库</span></button>
              <button
                onClick={openReadLater}
                className={`command-desk-nav-item w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all ${activeView === 'read-later' ? 'cloudnav-desktop-active bg-blue-50 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 font-medium' : 'text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-700'}`}
              ><div className="p-1"><Icon name="Bookmark" size={18} /></div><span>稍后阅读</span></button>
              <button
                onClick={openGithub}
                className={`command-desk-nav-item w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all ${activeView === 'github' ? 'cloudnav-desktop-active bg-blue-50 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 font-medium' : 'text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-700'}`}
              ><div className="p-1"><Icon name="Github" size={18} /></div><span>GitHub追踪</span></button>
            </div>
            
            <div className="flex items-center justify-between pt-4 pb-2 px-8">
               <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">分类目录</span>
               <button 
                  onClick={() => { if(!authToken) setIsAuthOpen(true); else setIsCatManagerOpen(true); }}
                  className="p-1 text-slate-400 hover:text-blue-500 hover:bg-slate-100 dark:hover:bg-slate-700 rounded"
                  title="管理分类"
               >
                  <Settings size={14} />
               </button>
            </div>

            {categories.filter(c => !c.parentId).map(cat => {
                const isLocked = cat.password && !unlockedCategoryIds.has(cat.id);
                const subCats = categories.filter(c => c.parentId === cat.id);
                return (
                  <div 
                    key={cat.id} 
                    className="relative px-4"
                    onMouseEnter={(e) => {
                      setHoveredCategory(cat.id);
                      setHoveredCategoryTop(e.currentTarget.getBoundingClientRect().top);
                    }}
                    onMouseLeave={() => setHoveredCategory(null)}
                  >
                    <button
                      onClick={() => handleCategoryClick(cat)}
                      onContextMenu={(e) => handleCategoryContextMenu(e, cat)}
                      className={`w-full flex items-center gap-3 px-4 py-2.5 rounded-xl transition-all group ${
                        selectedCategory === cat.id || (subCats.some(sc => sc.id === selectedCategory))
                          ? 'bg-blue-50 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 font-medium' 
                          : 'text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-700'
                      }`}
                    >
                      <div className={`p-1.5 rounded-lg transition-colors flex items-center justify-center ${selectedCategory === cat.id ? 'bg-blue-100 dark:bg-blue-800' : 'bg-slate-100 dark:bg-slate-800'}`}>
                        {isLocked ? <Lock size={16} className="text-amber-500" /> : <Icon name={cat.icon} size={16} />}
                      </div>
                      <span className="truncate flex-1 text-left">{cat.name}</span>
                      {(selectedCategory === cat.id || subCats.some(sc => sc.id === selectedCategory)) && <div className="w-1.5 h-1.5 rounded-full bg-blue-500"></div>}
                      {subCats.length > 0 && (
                        <div className="text-slate-400 group-hover:text-blue-500 transition-colors">
                          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="m9 18 6-6-6-6"/></svg>
                        </div>
                      )}
                    </button>

                    {/* 二级分类悬浮菜单 */}
                    {hoveredCategory === cat.id && subCats.length > 0 && (
                      <div 
                          className="fixed left-64 w-[166px] bg-white dark:bg-slate-800 rounded-xl shadow-xl border border-slate-200 dark:border-slate-700 py-2 z-[60] animate-in fade-in slide-in-from-left-2 duration-200 hidden lg:block"
                          style={{ top: hoveredCategoryTop }}
                        >
                        {/* 增加一个透明的遮罩层，防止鼠标移动到间隙时消失 */}
                        <div className="absolute -left-4 top-0 bottom-0 w-4 bg-transparent" />
                        
                        <div className="px-4 py-1 mb-1 border-b border-slate-100 dark:border-slate-700">
                          <span className="font-bold text-slate-400 uppercase tracking-widest" style={{ fontSize: '13px' }}>{cat.name} / 二级分类</span>
                        </div>
                        {subCats.map(subCat => {
                          const isSubLocked = isCategoryLocked(subCat.id);
                          return (
                            <button
                              key={subCat.id}
                              onClick={() => handleCategoryClick(subCat)}
                              onContextMenu={(e) => handleCategoryContextMenu(e, subCat)}
                              className={`w-full flex items-center gap-3 px-4 py-2 hover:bg-slate-50 dark:hover:bg-slate-700 transition-colors text-left ${
                                selectedCategory === subCat.id ? 'text-blue-600 dark:text-blue-400 font-medium' : 'text-slate-600 dark:text-slate-400'
                              }`}
                            >
                              {isSubLocked ? <Lock size={14} className="text-amber-500" /> : <Icon name={subCat.icon} size={14} />}
                              <span className="text-sm truncate">{subCat.name}</span>
                            </button>
                          );
                        })}
                      </div>
                    )}
                  </div>
                );
            })}
        </div>

        {/* Footer Actions */}
        <div className="p-4 border-t border-slate-100 dark:border-slate-700 bg-slate-50/50 dark:bg-slate-800/50 shrink-0">
            
            <div className="grid grid-cols-3 gap-2 mb-2">
                <button 
                    onClick={() => { if(!authToken) setIsAuthOpen(true); else setIsImportModalOpen(true); }}
                    className="flex flex-col items-center justify-center gap-1 p-2 text-xs text-slate-600 dark:text-slate-300 hover:bg-white dark:hover:bg-slate-700 rounded-lg border border-slate-200 dark:border-slate-600 transition-all"
                    title="导入书签"
                >
                    <Upload size={14} />
                    <span>导入</span>
                </button>
                
                <button 
                    onClick={() => { if(!authToken) setIsAuthOpen(true); else setIsBackupModalOpen(true); }}
                    className="flex flex-col items-center justify-center gap-1 p-2 text-xs text-slate-600 dark:text-slate-300 hover:bg-white dark:hover:bg-slate-700 rounded-lg border border-slate-200 dark:border-slate-600 transition-all"
                    title="备份与恢复"
                >
                    <CloudCog size={14} />
                    <span>备份</span>
                </button>

                <button 
                    onClick={() => setIsSettingsModalOpen(true)}
                    className="flex flex-col items-center justify-center gap-1 p-2 text-xs text-slate-600 dark:text-slate-300 hover:bg-white dark:hover:bg-slate-700 rounded-lg border border-slate-200 dark:border-slate-600 transition-all"
                    title="AI 设置"
                >
                    <Settings size={14} />
                    <span>设置</span>
                </button>
            </div>
            
            <div className="flex items-center justify-between text-xs px-2 mt-2">
               <div className="flex items-center gap-1 text-slate-400">
                 {syncStatus === 'saving' && <Loader2 className="animate-spin w-3 h-3 text-blue-500" />}
                 {syncStatus === 'saved' && <CheckCircle2 className="w-3 h-3 text-green-500" />}
                 {syncStatus === 'error' && <AlertCircle className="w-3 h-3 text-red-500" />}
                 {!isOnline ? <span className="text-amber-500">离线{pendingSyncCount ? ` · 待同步 ${pendingSyncCount}` : ''}</span> : syncStatus === 'saving' ? <span className="text-blue-600">同步中…</span> : syncStatus === 'error' ? <span className="text-red-600">待同步{pendingSyncCount ? ` ${pendingSyncCount}` : ''}</span> : syncStatus === 'saved' ? <span className="text-green-600">刚刚已保存</span> : authToken ? <span className="text-slate-500">云端就绪</span> : <span className="text-slate-400">本地模式</span>}
               </div>

               <a 
                 href={GITHUB_REPO_URL} 
                 target="_blank" 
                 rel="noopener noreferrer"
                 className="flex items-center gap-1 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 transition-colors"
                 title="Fork this project on GitHub"
               >
                 <GitFork size={14} />
                 <span>项目仓库 v1.8.2</span>
               </a>
            </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="cloudnav-desktop-main flex-1 flex flex-col h-full bg-slate-50 dark:bg-slate-900 overflow-hidden relative">
        
        {/* Header */}
        <header className="cloudnav-desktop-header h-16 px-4 lg:px-8 flex items-center justify-between bg-white/80 dark:bg-slate-800/80 backdrop-blur-md border-b border-slate-200 dark:border-slate-700 sticky top-0 z-10 shrink-0">
          <div className="flex items-center gap-4 flex-1">
            <button onClick={() => setSidebarOpen(true)} className="lg:hidden p-2 -ml-2 text-slate-600 dark:text-slate-300">
              <Menu size={24} />
            </button>

            {/* 搜索模式切换 + 搜索框 */}
            <div className="flex items-center gap-3 flex-1 min-w-0">
              {/* 移动端搜索图标 - 仅在手机端显示，平板端隐藏 */}
              <button 
                onClick={() => {
                  setIsMobileSearchOpen(!isMobileSearchOpen);
                  // 手机端点击搜索图标时默认使用站外搜索
                  if (searchMode !== 'external') {
                    handleSearchModeChange('external');
                  }
                }}
                className="sm:flex md:hidden lg:hidden p-2 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700 rounded-full transition-colors"
                title="搜索"
              >
                <Search size={20} />
              </button>

              {/* 搜索模式切换 - 平板端和桌面端显示，手机端隐藏 */}
              <div className="hidden sm:hidden md:flex lg:flex items-center gap-2 flex-shrink-0">
                <div className="flex items-center bg-slate-100 dark:bg-slate-700 rounded-full p-1">
                  <button
                    onClick={() => handleSearchModeChange('internal')}
                    className={`px-3 py-1 text-xs font-medium rounded-full transition-all flex items-center justify-center min-h-[24px] min-w-[40px] ${
                      searchMode === 'internal'
                        ? 'bg-white dark:bg-slate-600 text-blue-600 dark:text-blue-400 shadow-sm'
                        : 'text-slate-600 dark:text-slate-300 hover:text-slate-800 dark:hover:text-slate-100'
                    }`}
                    title="站内搜索"
                  >
                    站内
                  </button>
                  <button
                    onClick={() => handleSearchModeChange('external')}
                    className={`px-3 py-1 text-xs font-medium rounded-full transition-all flex items-center justify-center min-h-[24px] min-w-[40px] ${
                      searchMode === 'external'
                        ? 'bg-white dark:bg-slate-600 text-blue-600 dark:text-blue-400 shadow-sm'
                        : 'text-slate-600 dark:text-slate-300 hover:text-slate-800 dark:hover:text-slate-100'
                    }`}
                    title="站外搜索"
                  >
                    站外
                  </button>
                </div>
                
                {/* 搜索配置管理按钮 */}
                {searchMode === 'external' && (
                  <button
                    onClick={() => setIsSearchConfigModalOpen(true)}
                    className="p-1.5 text-slate-400 hover:text-blue-500 hover:bg-slate-100 dark:hover:bg-slate-700 rounded-full transition-colors"
                    title="管理搜索源"
                  >
                    <Settings size={14} />
                  </button>
                )}
              </div>

              {/* 搜索框 */}
              <div className={`relative w-full max-w-lg ${isMobileSearchOpen ? 'block' : 'hidden'} sm:block`}>
                {/* 搜索源选择弹出窗口 */}
                {searchMode === 'external' && showSearchSourcePopup && (
                  <div 
                    className="absolute left-0 top-full mt-2 w-full bg-white dark:bg-slate-800 rounded-lg shadow-lg border border-slate-200 dark:border-slate-700 p-3 z-50"
                    onMouseEnter={() => setIsPopupHovered(true)}
                    onMouseLeave={() => setIsPopupHovered(false)}
                  >
                    <div className="grid grid-cols-5 sm:grid-cols-5 gap-2">
                      {externalSearchSources
                        .filter(source => source.enabled)
                        .map((source, index) => (
                          <button
                            key={index}
                            onClick={() => handleSearchSourceSelect(source)}
                            onMouseEnter={() => setHoveredSearchSource(source)}
                            onMouseLeave={() => setHoveredSearchSource(null)}
                            className="px-2 py-2 text-sm rounded-md hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 flex items-center gap-1 justify-center"
                          >
                            <img 
                              src={getSearchSourceIconUrl(source.url)}
                              alt={source.name}
                              className="w-4 h-4"
                              onError={(e) => {
                                const target = e.target as HTMLImageElement;
                                target.src = 'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxNiIgaGVpZ2h0PSIxNiIgdmlld0JveD0iMCAwIDI0IDI0IiBmaWxsPSJub25lIiBzdHJva2U9ImN1cnJlbnRDb2xvciIgc3Ryb2tlLXdpZHRoPSIyIiBzdHJva2UtbGluZWNhcD0icm91bmQiIHN0cm9rZS1saW5lam9pbj0icm91bmQiIGNsYXNzPSJsdWNpZGUgbHVjaWRlLXNlYXJjaCI+PHBhdGggZD0ibTIxIDIxLTQuMzQtNC4zNCI+PC9wYXRoPjxjaXJjbGUgY3g9IjExIiBjeT0iMTEiIHI9IjgiPjwvY2lyY2xlPjwvc3ZnPg==';
                              }}
                            />
                            <span className="truncate hidden sm:inline">{source.name}</span>
                          </button>
                        ))}
                    </div>
                  </div>
                )}

                {!searchQuery.trim() && searchHistory.length > 0 && (
                  <div className="absolute left-0 top-full mt-2 w-full bg-white dark:bg-slate-800 rounded-lg shadow-lg border border-slate-200 dark:border-slate-700 p-3 z-40">
                    <div className="flex items-center justify-between mb-2"><span className="text-xs font-semibold text-slate-500">最近搜索</span><button onClick={() => { setSearchHistory([]); localStorage.removeItem(SEARCH_HISTORY_KEY); }} className="text-xs text-slate-400 hover:text-red-500">清空</button></div>
                    <div className="flex flex-wrap gap-2">{searchHistory.map(query => <button key={query} onClick={() => { setSearchQuery(query); setActiveView('links'); }} className="max-w-full truncate rounded-full bg-slate-100 dark:bg-slate-700 px-3 py-1.5 text-xs text-slate-600 dark:text-slate-200 hover:bg-blue-100 hover:text-blue-600">{query}</button>)}</div>
                  </div>
                )}

                {searchMode === 'internal' && searchQuery.trim() && unifiedSearchResults.length > 0 && (
                  <div className="absolute left-0 top-full mt-2 w-full rounded-xl border border-slate-200 bg-white p-2 shadow-xl dark:border-slate-700 dark:bg-slate-800 z-40" data-unified-search-results>
                    <div className="px-2 py-1 text-[11px] font-semibold tracking-wider text-slate-400">统一搜索 · {unifiedSearchResults.length} 条</div>
                    {unifiedSearchResults.map(result => <button key={`${result.kind}-${result.id}`} type="button" onClick={() => openUnifiedResult(result)} className="flex w-full items-center gap-3 rounded-lg px-2 py-2 text-left hover:bg-slate-50 dark:hover:bg-slate-700"><span className="w-16 shrink-0 text-[10px] font-bold tracking-wider text-teal-600">{result.kind === 'rss' ? 'RSS' : result.kind === 'read-later' ? '稍后阅读' : result.kind === 'github' ? 'GITHUB' : result.kind === 'inspiration' ? '灵感' : result.kind === 'reading' ? '阅读库' : '网站'}</span><span className="min-w-0 flex-1"><strong className="block truncate text-sm text-slate-700 dark:text-slate-200">{result.title}</strong><small className="block truncate text-xs text-slate-400">{result.subtitle}</small></span></button>)}
                  </div>
                )}
                
                {/* 搜索图标 */}
                <div 
                  className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 cursor-pointer"
                  onMouseEnter={() => searchMode === 'external' && setIsIconHovered(true)}
                  onMouseLeave={() => setIsIconHovered(false)}
                  onClick={() => {
                    // 移动端点击事件：显示搜索源选择窗口
                    if (searchMode === 'external') {
                      setShowSearchSourcePopup(!showSearchSourcePopup);
                    }
                  }}
                >
                  {searchMode === 'internal' ? (
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-search">
                      <path d="m21 21-4.35-4.35"></path>
                      <circle cx="11" cy="11" r="8"></circle>
                    </svg>
                  ) : (hoveredSearchSource || selectedSearchSource) ? (
                    <img 
                      src={getSearchSourceIconUrl((hoveredSearchSource || selectedSearchSource).url)}
                      alt={(hoveredSearchSource || selectedSearchSource).name}
                      className="w-4 h-4"
                      onError={(e) => {
                        const target = e.target as HTMLImageElement;
                        target.src = 'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxNiIgaGVpZ2h0PSIxNiIgdmlld0JveD0iMCAwIDI0IDI0IiBmaWxsPSJub25lIiBzdHJva2U9ImN1cnJlbnRDb2xvciIgc3Ryb2tlLXdpZHRoPSIyIiBzdHJva2UtbGluZWNhcD0icm91bmQiIHN0cm9rZS1saW5lam9pbj0icm91bmQiIGNsYXNzPSJsdWNpZGUgbHVjaWRlLXNlYXJjaCI+PHBhdGggZD0ibTIxIDIxLTQuMzQtNC4zNCI+PC9wYXRoPjxjaXJjbGUgY3g9IjExIiBjeT0iMTEiIHI9IjgiPjwvY2lyY2xlPjwvc3ZnPg==';
                      }}
                    />
                  ) : (
                    <Search size={16} />
                  )}
                </div>
                
                <input
                  type="text"
                  placeholder={
                    searchMode === 'internal' 
                      ? "搜索站内内容..." 
                      : selectedSearchSource 
                        ? `在${selectedSearchSource.name}搜索内容` 
                        : "搜索站外内容..."
                  }
                  value={searchQuery}
                  onChange={(e) => {
                    const value = e.target.value;
                    setSearchQuery(value);
                  }}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' && e.currentTarget.value.trim()) saveSearchQuery(e.currentTarget.value);
                    if (e.key === 'Enter' && searchMode === 'external') handleExternalSearch();
                  }}
                  className="w-full pl-9 pr-20 py-2 rounded-full bg-slate-100 dark:bg-slate-700/50 border-none text-sm focus:ring-2 focus:ring-blue-500 dark:text-white placeholder-slate-400 outline-none transition-all"
                  // 移动端优化：防止页面缩放
                  style={{ fontSize: '16px' }}
                  inputMode="search"
                  enterKeyHint="search"
                />
                
                {searchMode === 'external' && searchQuery.trim() && (
                  <button
                    onClick={handleExternalSearch}
                    className="absolute right-16 top-1/2 -translate-y-1/2 p-1 text-slate-400 hover:text-blue-500"
                    title="执行站外搜索"
                  >
                    <ExternalLink size={14} />
                  </button>
                )}
                
                {searchMode === 'internal' && (
                  <button
                    onClick={() => setIsAdvancedFilterOpen(open => !open)}
                    className={`absolute right-9 top-1/2 -translate-y-1/2 p-1 rounded-full transition-all ${advancedFilterActive ? 'text-blue-600 bg-blue-100 dark:bg-blue-900/40 dark:text-blue-300' : 'text-slate-400 hover:text-blue-500 hover:bg-slate-200 dark:hover:bg-slate-600'}`}
                    title="高级筛选"
                  >
                    <Filter size={14} />
                  </button>
                )}

                {isAdvancedFilterOpen && searchMode === 'internal' && (
                  <AdvancedSearchBar
                    isOpen={true}
                    onClose={() => setIsAdvancedFilterOpen(false)}
                    tags={allTags}
                    workspaces={[]}
                    filters={advancedFilters}
                    onFilterChange={(next) => setAdvancedFilters(current => ({ ...current, ...next }))}
                  />
                )}

                {searchQuery.trim() && (
                  <button
                    onClick={() => setSearchQuery('')}
                    className="absolute right-2 top-1/2 -translate-y-1/2 w-6 h-6 flex items-center justify-center rounded-full bg-slate-200 dark:bg-slate-600 text-slate-500 dark:text-slate-300 hover:bg-red-100 dark:hover:bg-red-900/30 hover:text-red-500 dark:hover:text-red-400 transition-all"
                    title="清空搜索"
                  >
                    <X size={12} strokeWidth={2.5} />
                  </button>
                )}
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <TopWeather value={workbenchTools} onChange={updateWorkbenchTools} />

            {/* 视图切换控制器 - 移动端：搜索框展开时隐藏，桌面端始终显示 */}
            <div className={`${isMobileSearchOpen ? 'hidden' : 'flex'} lg:flex items-center bg-slate-100 dark:bg-slate-700 rounded-full p-1`}>
              <button
                onClick={() => handleViewModeChange('simple')}
                className={`px-3 py-1 text-xs font-medium rounded-full transition-all ${
                  siteSettings.cardStyle === 'simple'
                    ? 'bg-white dark:bg-slate-600 text-blue-600 dark:text-blue-400 shadow-sm'
                    : 'text-slate-600 dark:text-slate-300 hover:text-slate-800 dark:hover:text-slate-100'
                }`}
                title="简约版视图"
              >
                简约
              </button>
              <button
                onClick={() => handleViewModeChange('detailed')}
                className={`px-3 py-1 text-xs font-medium rounded-full transition-all ${
                  siteSettings.cardStyle === 'detailed'
                    ? 'bg-white dark:bg-slate-600 text-blue-600 dark:text-blue-400 shadow-sm'
                    : 'text-slate-600 dark:text-slate-300 hover:text-slate-800 dark:hover:text-slate-100'
                }`}
                title="详情版视图"
              >
                详情
              </button>
            </div>

            {authToken && !isOrganizeMode && inboxLinks.length > 0 && (
              <button onClick={() => { openLinksView(INBOX_ID); setOrganizeIndex(0); setIsOrganizeMode(true); }}
                className="flex items-center gap-1 px-3 py-1.5 text-xs font-medium bg-amber-50 dark:bg-amber-900/20 text-amber-600 dark:text-amber-300 rounded-full hover:bg-amber-100 dark:hover:bg-amber-900/30 transition-colors"
              >
                整理 {inboxLinks.length}
              </button>
            )}

            {/* 主题切换按钮 - 移动端：搜索框展开时隐藏，桌面端始终显示 */}
            <button onClick={toggleTheme} className={`${isMobileSearchOpen ? 'hidden' : 'flex'} lg:flex p-2 rounded-full text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700`}>
              {darkMode ? <Sun size={18} /> : <Moon size={18} />}
            </button>

            {/* 登录/退出按钮 - 移动端：搜索框展开时隐藏，桌面端始终显示 */}
            <div className={`${isMobileSearchOpen ? 'hidden' : 'flex'}`}>
              {!authToken ? (
                  <button onClick={() => setIsAuthOpen(true)} className="flex items-center gap-2 bg-slate-200 dark:bg-slate-700 px-3 py-1.5 rounded-full text-xs font-medium">
                      <Cloud size={14} /> <span className="hidden sm:inline">登录</span>
                  </button>
              ) : (
                  <button onClick={handleLogout} className="flex items-center gap-2 bg-slate-200 dark:bg-slate-700 px-3 py-1.5 rounded-full text-xs font-medium">
                      <LogOut size={14} /> <span className="hidden sm:inline">退出</span>
                  </button>
              )}
            </div>

            {/* 添加按钮 - 移动端：搜索框展开时隐藏，桌面端始终显示 */}
            <div className={`${isMobileSearchOpen ? 'hidden' : 'flex'}`}>
              <button
                onClick={() => openInspiration()}
                className="mr-1 hidden items-center gap-2 rounded-full border border-teal-200 bg-teal-50 px-3 py-2 text-sm font-medium text-teal-700 hover:bg-teal-100 lg:flex"
                title="快速记录灵感"
                data-quick-capture-trigger
              >
                <FileText size={15} /> <span>记录</span>
              </button>
              <button
                onClick={() => { if(!authToken) setIsAuthOpen(true); else { setEditingLink(undefined); setIsModalOpen(true); }}}
                className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white px-3 py-2 rounded-full text-sm font-medium shadow-lg shadow-blue-500/30"
              >
                <Plus size={16} /> <span className="hidden sm:inline">添加</span>
              </button>
            </div>
          </div>
        </header>

        {/* Content Scroll Area */}
        <div className="cloudnav-desktop-content flex-1 overflow-y-auto p-4 lg:px-10 lg:pb-12 lg:pt-6 xl:px-12 space-y-8">

            {isOrganizeMode && (
              <OrganizeModeBar
                isActive={true}
                totalCount={inboxLinks.length}
                currentIndex={Math.min(organizeIndex, Math.max(inboxLinks.length - 1, 0))}
                onAccept={() => {
                const current = inboxLinks[organizeIndex];
                if (!current) { setIsOrganizeMode(false); setOrganizeIndex(0); return; }
                const nextLinks = links.map(l => l.id === current.id ? { ...l, categoryId: 'common', status: 'read' as const, updatedAt: Date.now() } : l);
                updateData(nextLinks, categories);
                if (organizeIndex < inboxLinks.length - 1) setOrganizeIndex(i => i + 1);
                else { setIsOrganizeMode(false); setOrganizeIndex(0); }
                }}
                onDelete={() => {
                const current = inboxLinks[organizeIndex];
                if (!current) { setIsOrganizeMode(false); setOrganizeIndex(0); return; }
                updateData(links.filter(l => l.id !== current.id), categories);
                if (organizeIndex < inboxLinks.length - 1) setOrganizeIndex(i => i + 1);
                else { setIsOrganizeMode(false); setOrganizeIndex(0); }
                }}
                onSkip={() => {
                if (organizeIndex < inboxLinks.length - 1) setOrganizeIndex(i => i + 1);
                else { setIsOrganizeMode(false); setOrganizeIndex(0); }
                }}
                onAiOrganize={handleAiOrganizeCurrent}
                isAiOrganizing={isAiOrganizing}
                onExit={() => { setIsOrganizeMode(false); setOrganizeIndex(0); }}
              />
            )}

            <React.Suspense fallback={<div className="flex min-h-[420px] items-center justify-center text-slate-400"><Loader2 className="mr-2 animate-spin" size={18} />正在打开工作区…</div>}>
            <SpatialViewTransition viewKey={activeView}>
              {activeView === 'workbench' && (
                <WorkbenchPage
                links={links}
                categories={categories}
                config={dashboardConfig}
                 onConfigChange={updateDashboardConfig}
                 workbenchTools={workbenchTools}
                 onWorkbenchToolsChange={updateWorkbenchTools}
                 aiConfig={aiConfig}
                onOpenInbox={() => { openLinksView(INBOX_ID); setOrganizeIndex(0); setIsOrganizeMode(true); }}
                 onClickLink={(link) => { void openWebsiteWithSummary(link); }}
                onSelectCategory={(categoryId) => {
                  const category = categories.find(c => c.id === categoryId);
                  if (category) handleCategoryClick(category);
                }}
                />
              )}

            {activeView === 'rss' && (
                <React.Suspense fallback={<div className="flex min-h-[420px] items-center justify-center text-slate-400"><Loader2 className="mr-2 animate-spin" size={18} />正在加载资讯中心…</div>}>
                  <RssPage onSaveArticle={saveRssArticleToLinks} onSaveToReadLater={saveRssArticleToReadLater} onSaveToReading={saveRssArticleToReading} onCaptureInspiration={captureRssArticle} initialArticleId={unifiedSearchTarget?.kind === 'rss' ? unifiedSearchTarget.id : undefined} onInitialArticleConsumed={() => setUnifiedSearchTarget(null)} aiConfig={aiConfig} />
                </React.Suspense>
              )}

              {activeView === 'inspiration' && (
                <InspirationPage
                  aiConfig={aiConfig}
                  initialCapture={quickCaptureSeed}
                  initialId={unifiedSearchTarget?.kind === 'inspiration' ? unifiedSearchTarget.id : undefined}
                  onInitialIdConsumed={() => setUnifiedSearchTarget(null)}
                  onNotice={(message) => showToast(message, { type: message.includes('失败') ? 'error' : 'success' })}
                  onOpenUrl={(url) => window.open(url, '_blank', 'noopener,noreferrer')}
                />
              )}

              {activeView === 'read-later' && (
                <ReadLaterPage
                  initialId={unifiedSearchTarget?.kind === 'read-later' ? unifiedSearchTarget.id : undefined}
                  onInitialIdConsumed={() => setUnifiedSearchTarget(null)}
                  onNotice={(message) => showToast(message, { type: 'info' })}
                  onOpenUrl={(url) => window.open(url, '_blank', 'noopener,noreferrer')}
                />
              )}

              {activeView === 'github' && (
                <GithubPage
                  initialId={unifiedSearchTarget?.kind === 'github' ? unifiedSearchTarget.id : undefined}
                  onInitialIdConsumed={() => setUnifiedSearchTarget(null)}
                  onNotice={(message) => showToast(message, { type: message.includes('失败') || message.includes('限流') ? 'error' : 'success' })}
                  onOpenUrl={(url) => window.open(url, '_blank', 'noopener,noreferrer')}
                />
              )}

              {activeView === 'inbox' && (
                <InboxPage
                  links={links}
                  onOpenUrl={(url) => window.open(url, '_blank', 'noopener,noreferrer')}
                  onCaptureRss={captureRssArticle}
                  onMarkLinkDone={(linkId) => updateData(links.map(link => link.id === linkId ? { ...link, status: 'read' as const, updatedAt: Date.now() } : link), categories)}
                />
              )}

              {activeView === 'reading' && (
                <ReadingWorkspacePage
                  initialId={unifiedSearchTarget?.kind === 'reading' ? unifiedSearchTarget.id : undefined}
                  onInitialIdConsumed={() => setUnifiedSearchTarget(null)}
                  initialCapture={readingCaptureSeed}
                  aiConfig={aiConfig}
                  onOpenUrl={(url) => window.open(url, '_blank', 'noopener,noreferrer')}
                  onNotice={(message) => showToast(message, { type: message.includes('失败') ? 'error' : 'success' })}
                />
              )}

            {activeView === 'links' && (
              <DesktopLibraryPage
                links={links.filter(link => !link.deletedAt)}
                pinnedLinks={pinnedLinks}
                displayedLinks={displayedLinks}
                otherCategoryResults={otherCategoryResults}
                categories={categories}
                selectedCategory={selectedCategory}
                searchQuery={searchQuery}
                isBatchEditMode={isBatchEditMode}
                selectedLinks={selectedLinks}
                aiConfig={aiConfig}
                onSearch={setSearchQuery}
                onAdd={() => { if (!authToken) setIsAuthOpen(true); else { setEditingLink(undefined); setIsModalOpen(true); } }}
                onOpen={(link) => { void openWebsiteWithSummary(link); }}
                 onDetails={(link) => { setDetailsOrigin('right'); setSelectedLinkId(link.id); }}
                 onEdit={(link) => { setEditingLink(link); setIsModalOpen(true); }}
                 onDelete={(link) => handleDeleteLink(link.id)}
                 onMoveLink={(link, direction) => handleQuickMoveLink(link.id, direction)}
                 onSaveToReadLater={saveLinkToReadLater}
                 onTogglePin={(link, event) => togglePin(link.id, event)}
                onContextMenu={handleContextMenu}
                onToggleBatchMode={toggleBatchEditMode}
                onToggleSelection={toggleLinkSelection}
                onSelectAll={handleSelectAll}
                onBatchDelete={handleBatchDelete}
                onExitBatchMode={() => { setIsBatchEditMode(false); setSelectedLinks(new Set()); }}
              />
            )}
            </SpatialViewTransition>
            </React.Suspense>
        </div>
      </main>

          {isModalOpen && (
            <LinkModal
              isOpen={true}
              onClose={() => { setIsModalOpen(false); setEditingLink(undefined); setPrefillLink(undefined); }}
              onSave={editingLink ? handleEditLink : handleAddLink}
              onDelete={editingLink ? handleDeleteLink : undefined}
              categories={categories}
              links={links}
              initialData={editingLink || (prefillLink as LinkItem)}
              aiConfig={aiConfig}
              defaultCategoryId={selectedCategory !== 'all' ? selectedCategory : undefined}
            />
          )}

          {/* 右键菜单 */}
          {contextMenu.isOpen && (
            <ContextMenu
              isOpen={true}
              position={contextMenu.position}
              targetType={contextMenu.type}
              isCategoryEditable={contextMenu.category?.id !== 'common'}
              onClose={closeContextMenu}
              onCopyLink={copyLinkToClipboard}
              onShowQRCode={showQRCode}
              onEditLink={editLinkFromContextMenu}
              onDeleteLink={deleteLinkFromContextMenu}
              onTogglePin={togglePinFromContextMenu}
              onOpenCategory={openCategoryFromContextMenu}
              onEditCategory={editCategoryFromContextMenu}
              onOrganizeCategory={organizeCategoryFromContextMenu}
              onRenameCategory={renameCategoryFromContextMenu}
              onStructureCategory={structureCategoryFromContextMenu}
              onDeleteCategory={deleteCategoryFromContextMenu}
            />
          )}

          {categoryActionAuth.isOpen && (
            <CategoryActionAuthModal
              isOpen={true}
              onClose={closeCategoryActionAuth}
              onVerify={handleCategoryActionAuth}
              onVerified={handleCategoryActionVerified}
              actionType={categoryActionAuth.action}
              categoryName={categoryActionAuth.categoryName}
            />
          )}

          {/* 二维码模态框 */}
          {selectedLinkId && (
            <LinkDetailsDrawer
              link={links.find(l => l.id === selectedLinkId) || null}
              isOpen={true}
              origin={detailsOrigin}
              onClose={() => setSelectedLinkId(null)}
              categories={categories}
              onUpdate={(linkId, updates) => {
                const nextLinks = links.map(l => l.id === linkId ? { ...l, ...updates, updatedAt: Date.now() } : l);
                updateData(nextLinks, categories);
              }}
            />
          )}

          {isSyncConflict && (
            <SyncConflictModal
              isOpen={true}
               onClose={() => { syncConflictOpenRef.current = false; setIsSyncConflict(false); setSyncConflictResolve(null); setSyncConflictPreview(null); }}
               onUseLocal={() => { syncConflictResolve?.useLocal(); setIsSyncConflict(false); setSyncConflictResolve(null); setSyncConflictPreview(null); }}
               onUseCloud={() => { syncConflictResolve?.useCloud(); setIsSyncConflict(false); setSyncConflictResolve(null); setSyncConflictPreview(null); }}
               onMerge={() => { syncConflictResolve?.merge(); setIsSyncConflict(false); setSyncConflictResolve(null); setSyncConflictPreview(null); }}
               mergePreview={syncConflictPreview}
            />
          )}

          <MobileBottomNav
            activeView={activeView}
            onLinks={() => openLinksView('all')}
            onWorkbench={openWorkbench}
            onRss={openRssReader}
            onAdd={() => { if (!authToken) setIsAuthOpen(true); else { setEditingLink(undefined); setIsModalOpen(true); } }}
            onSettings={() => setIsSettingsModalOpen(true)}
          />
          <InstallPrompt />

          <WebsiteSummaryPanel
            state={websiteSummary}
            onClose={() => { websiteSummaryRequestRef.current += 1; setWebsiteSummary(null); }}
            onRetry={() => {
              if (websiteSummary) void openWebsiteWithSummary(websiteSummary.link as LinkItem, { openExternal: false });
            }}
            onOpen={() => {
              if (websiteSummary) window.open(websiteSummary.link.url, '_blank', 'noopener,noreferrer');
            }}
          />

          {qrCodeModal.isOpen && (
            <QRCodeModal
              isOpen={true}
              url={qrCodeModal.url || ''}
              title={qrCodeModal.title || ''}
              onClose={() => setQrCodeModal({ isOpen: false, url: '', title: '' })}
            />
          )}
        </>
      )}
      </div>
      </AppShell>
    </React.Suspense>
  );
}

export default App;

