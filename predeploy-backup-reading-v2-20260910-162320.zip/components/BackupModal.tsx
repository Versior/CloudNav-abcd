import React, { useState, useEffect, useRef } from 'react';
import { useModalA11y } from './useModalA11y';
import { X, Cloud, Download, Upload, CheckCircle2, AlertCircle, RefreshCw, Save } from 'lucide-react';
import { Category, LinkItem, WebDavConfig, SearchConfig, AIConfig } from '../types';
import { RECOVERY_SNAPSHOTS_KEY } from '../constants/storageKeys';
import { GITHUB_WATCH_KEY, INSPIRATIONS_KEY, READ_LATER_KEY, READING_DOCUMENTS_KEY, RSS_STATE_KEY } from '../constants/storageKeys';
import { normalizeInspirations } from '../services/inspirationService';
import { normalizeReadLater } from '../services/readLaterService';
import { normalizeGithubWatch } from '../services/githubService';
import { normalizeRecoverySnapshots, type RecoverySnapshot } from '../services/recoverySnapshots';
import { checkWebDavConnection, uploadBackup, uploadBackupWithTimestamp, downloadBackup, listBackups } from '../services/webDavService';
import { generateBookmarkHtml, downloadHtmlFile } from '../services/exportService';
import HistoryPanel from './HistoryPanel';
import { createBackupEnvelope } from '../services/backupService';
import { readReadingDocuments } from '../services/readingStorage';
import { readRssState } from '../services/rssService';
import type { WorkbenchToolsState } from '../services/workbenchTools';

interface BackupModalProps {
  isOpen: boolean;
  onClose: () => void;
  links: LinkItem[];
  categories: Category[];
  onRestore: (links: LinkItem[], categories: Category[], version?: number, workbenchTools?: WorkbenchToolsState) => void;
  webDavConfig: WebDavConfig;
  onSaveWebDavConfig: (config: WebDavConfig) => void | Promise<void>;
  searchConfig: SearchConfig;
  onRestoreSearchConfig: (searchConfig: SearchConfig) => void;
  authToken?: boolean;
  aiConfig: AIConfig;
  onRestoreAIConfig: (aiConfig: AIConfig) => void;
  workbenchTools: WorkbenchToolsState;
  dataVersion?: number;
}

const BackupModal: React.FC<BackupModalProps> = ({
  isOpen, onClose, links, categories, onRestore, webDavConfig, onSaveWebDavConfig, searchConfig, onRestoreSearchConfig, authToken, aiConfig, onRestoreAIConfig, workbenchTools, dataVersion
}) => {
  const readWorkspacePayload = () => {
    try {
      return {
        inspirations: normalizeInspirations(JSON.parse(localStorage.getItem(INSPIRATIONS_KEY) || '[]')),
        readLater: normalizeReadLater(JSON.parse(localStorage.getItem(READ_LATER_KEY) || '[]')),
        githubWatch: normalizeGithubWatch(JSON.parse(localStorage.getItem(GITHUB_WATCH_KEY) || '[]')),
        readingDocuments: readReadingDocuments(),
        rssState: readRssState(),
      };
    } catch { return { inspirations: [], readLater: [], githubWatch: [] }; }
  };
  const containerRef = useRef<HTMLDivElement>(null);
  useModalA11y(isOpen, onClose, containerRef);
  const [config, setConfig] = useState<WebDavConfig>(webDavConfig);
  const [backupList, setBackupList] = useState<string[]>([]);
  const [loadingList, setLoadingList] = useState(false);
  const [isTesting, setIsTesting] = useState(false);
  const [testResult, setTestResult] = useState<'success' | 'fail' | null>(null);
  const [syncStatus, setSyncStatus] = useState<'idle' | 'uploading' | 'downloading' | 'success' | 'error'>('idle');
  const [statusMsg, setStatusMsg] = useState('');
  const [recoverySnapshots, setRecoverySnapshots] = useState<RecoverySnapshot[]>([]);

  useEffect(() => {
    if(isOpen) {
        setConfig(webDavConfig);
        setTestResult(null);
        setSyncStatus('idle');
        try { setRecoverySnapshots(normalizeRecoverySnapshots(JSON.parse(localStorage.getItem(RECOVERY_SNAPSHOTS_KEY) || '[]'))); } catch { setRecoverySnapshots([]); }
    }
  }, [isOpen, webDavConfig]);

  const handleTestConnection = async () => {
    setIsTesting(true);
    setTestResult(null);
    const success = await checkWebDavConnection(config);
    setTestResult(success ? 'success' : 'fail');
    setIsTesting(false);
  };

  const handleSaveConfig = () => {
    onSaveWebDavConfig(config);
    if (config.enabled) {
        handleTestConnection();
    }
  };

  const handleBackupToCloud = async () => {
    setSyncStatus('uploading');
    setStatusMsg('正在上传...');
    const success = await uploadBackup(config, { links, categories, searchConfig, workbenchTools, ...readWorkspacePayload() });
    if (success) {
        setSyncStatus('success');
        setStatusMsg('备份成功！');
    } else {
        setSyncStatus('error');
        setStatusMsg('上传失败:请检查 WebDAV 地址(须 https 公网)、用户名/密码是否正确。');
    }
  };

  const handleBackupToCloudWithTimestamp = async () => {
    setSyncStatus('uploading');
    setStatusMsg('正在上传...');
    const result = await uploadBackupWithTimestamp(config, { links, categories, searchConfig, workbenchTools, ...readWorkspacePayload() });
    if (result.success) {
        setSyncStatus('success');
        setStatusMsg(`备份成功！文件名: ${result.filename}`);
    } else {
        setSyncStatus('error');
        setStatusMsg('上传失败:请检查 WebDAV 地址(须 https 公网)、用户名/密码是否正确。');
    }
  };

  const handleRestoreFromCloud = async (filename?: string) => {
    if (!confirm("确定要从 WebDAV 恢复吗？这将覆盖当前的本地数据。")) return;

    setSyncStatus('downloading');
    setStatusMsg('正在下载...');
    const data = await downloadBackup(config, filename);
    
    if (data) {
        onRestore(data.links, data.categories, undefined, data.workbenchTools);
        if (data.inspirations) localStorage.setItem(INSPIRATIONS_KEY, JSON.stringify(data.inspirations));
        if (data.readLater) localStorage.setItem(READ_LATER_KEY, JSON.stringify(data.readLater));
        if (data.githubWatch) localStorage.setItem(GITHUB_WATCH_KEY, JSON.stringify(data.githubWatch));
        if (data.readingDocuments) localStorage.setItem(READING_DOCUMENTS_KEY, JSON.stringify(data.readingDocuments));
        if (data.rssState) localStorage.setItem(RSS_STATE_KEY, JSON.stringify(data.rssState));
        window.dispatchEvent(new Event('cloudnav-workspace-data-changed'));
        // 恢复搜索配置（如果存在）
        if (data.searchConfig) {
            onRestoreSearchConfig(data.searchConfig);
        }
        // 恢复AI配置（如果存在）
        if (data.aiConfig) {
            onRestoreAIConfig(data.aiConfig);
        }
        setSyncStatus('success');
        setStatusMsg('恢复成功！');
    } else {
        setSyncStatus('error');
        setStatusMsg('下载失败或文件格式错误。');
    }
  };

  const handleListBackups = async () => {
    setLoadingList(true);
    const files = await listBackups(config);
    setBackupList(files);
    setLoadingList(false);
  };

  const handleExportHtml = () => {
    const html = generateBookmarkHtml(links, categories);
    const dateStr = new Date().toISOString().split('T')[0];
    downloadHtmlFile(html, `bookmarks_${dateStr}.html`);
  };

  const sanitizeLinksForBackup = (sourceLinks: LinkItem[]) => sourceLinks.map(link => ({
    ...link,
    credentials: link.credentials?.map(credential => ({
      id: credential.id,
      label: credential.label,
      username: credential.username,
      account: credential.account,
      passwordCipher: credential.passwordCipher,
      passwordHint: credential.passwordHint,
      remark: credential.remark,
      updatedAt: credential.updatedAt,
    })),
  }));

  const handleExportJson = () => {
    const data = createBackupEnvelope({ links, categories, searchConfig, aiConfig, workbenchTools, ...readWorkspacePayload() }, dataVersion);
    const json = JSON.stringify(data, null, 2);
    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'navix_backup.json';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  if (!isOpen) return null;

  return (
    <div onClick={onClose} className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
      <div ref={containerRef} role="dialog" aria-modal="true" onClick={(e) => e.stopPropagation()} className="bg-white dark:bg-slate-800 rounded-2xl shadow-2xl w-full max-w-2xl overflow-hidden border border-slate-200 dark:border-slate-700 max-h-[90vh] flex flex-col">
        <div className="flex justify-between items-center p-4 border-b border-slate-200 dark:border-slate-700">
          <h3 className="text-lg font-semibold dark:text-white flex items-center gap-2">
            <Cloud className="text-blue-500" /> 备份与恢复
          </h3>
          <button onClick={onClose} aria-label="关闭" className="p-1 hover:bg-slate-100 dark:hover:bg-slate-700 rounded-full transition-colors">
            <X className="w-5 h-5 dark:text-slate-400" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-6 space-y-8">
            
            {/* Section 1: WebDAV Configuration */}
            <section className="space-y-4">
                <div className="flex items-center justify-between">
                    <h4 className="font-medium text-slate-800 dark:text-slate-200">WebDAV 设置 (坚果云/<a href="https://infini-cloud.net/en/modules/mypage/usage/" target="_blank" rel="noopener noreferrer" className="text-blue-500 hover:text-blue-600 underline">InfiniCloud</a>等)</h4>
                    <label className="flex items-center gap-2 cursor-pointer">
                        <input 
                            type="checkbox" 
                            checked={config.enabled}
                            onChange={(e) => setConfig({...config, enabled: e.target.checked})}
                            className="rounded text-blue-600 focus:ring-blue-500"
                        />
                        <span className="text-sm text-slate-600 dark:text-slate-400">启用 WebDAV</span>
                    </label>
                </div>

                <div className={`space-y-3 transition-opacity ${!config.enabled ? 'opacity-50 pointer-events-none' : ''}`}>
                    <div>
                        <label className="block text-xs font-medium text-slate-500 mb-1">服务器地址 (URL)</label>
                        <input 
                            type="text" 
                            value={config.url}
                            onChange={(e) => setConfig({...config, url: e.target.value})}
                            placeholder="https://dav.jianguoyun.com/dav/"
                            className="w-full p-2 text-sm rounded-lg border border-slate-300 dark:border-slate-600 dark:bg-slate-700 dark:text-white outline-none focus:ring-2 focus:ring-blue-500"
                        />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                        <div>
                            <label className="block text-xs font-medium text-slate-500 mb-1">用户名</label>
                            <input 
                                type="text" 
                                value={config.username}
                                onChange={(e) => setConfig({...config, username: e.target.value})}
                                className="w-full p-2 text-sm rounded-lg border border-slate-300 dark:border-slate-600 dark:bg-slate-700 dark:text-white outline-none focus:ring-2 focus:ring-blue-500"
                            />
                        </div>
                        <div>
                            <label className="block text-xs font-medium text-slate-500 mb-1">应用密码</label>
                            <input
                                type="password"
                                value={config.password}
                                onChange={(e) => setConfig({...config, password: e.target.value})}
                                className="w-full p-2 text-sm rounded-lg border border-slate-300 dark:border-slate-600 dark:bg-slate-700 dark:text-white outline-none focus:ring-2 focus:ring-blue-500"
                            />
                        </div>
                    </div>

                    <p className="text-xs text-amber-600 dark:text-amber-400 flex items-center gap-1">
                        <AlertCircle size={12}/> WebDAV 应用密码会保存在当前浏览器本地。请只在私人设备上启用。
                    </p>

                    <div className="flex items-center gap-3 pt-2">
                        <button
                            onClick={handleTestConnection}
                            disabled={isTesting}
                            className="px-3 py-1.5 text-xs font-medium bg-slate-100 dark:bg-slate-700 hover:bg-slate-200 dark:hover:bg-slate-600 rounded-md transition-colors"
                        >
                            {isTesting ? '连接中...' : '测试连接'}
                        </button>
                        <button 
                            onClick={handleSaveConfig}
                            className="px-3 py-1.5 text-xs font-medium bg-blue-600 text-white hover:bg-blue-700 rounded-md transition-colors flex items-center gap-1"
                        >
                            <Save size={12} /> 保存配置
                        </button>
                        <button
                            onClick={() => onSaveWebDavConfig({ url: '', username: '', password: '', enabled: false })}
                            className="px-3 py-1.5 text-xs font-medium bg-red-100 dark:bg-red-900/30 text-red-600 dark:text-red-400 hover:bg-red-200 dark:hover:bg-red-900/50 rounded-md transition-colors"
                        >
                            清除凭据
                        </button>
                        {testResult === 'success' && <span className="text-xs text-green-500 flex items-center gap-1"><CheckCircle2 size={12}/> 连接成功</span>}
                        {testResult === 'fail' && <span className="text-xs text-red-500 flex items-center gap-1"><AlertCircle size={12}/> 连接失败</span>}
                    </div>
                </div>
            </section>

            <hr className="border-slate-200 dark:border-slate-700" />

             <HistoryPanel onRestore={onRestore} />

             <section className="space-y-3">
               <div className="flex items-center justify-between gap-3"><div><h4 className="font-medium text-slate-800 dark:text-slate-200">本地恢复</h4><p className="text-xs text-slate-500 mt-1">每次本地修改前自动保留最近 5 个快照。</p></div><span className="text-xs text-slate-400">{recoverySnapshots.length}/5</span></div>
               {recoverySnapshots.length === 0 ? <div className="rounded-xl bg-slate-50 dark:bg-slate-700/30 p-3 text-xs text-slate-500">暂无本地恢复快照</div> : <div className="max-h-48 overflow-y-auto divide-y divide-slate-100 dark:divide-slate-700 rounded-xl border border-slate-200 dark:border-slate-700">{recoverySnapshots.map(snapshot => <div key={snapshot.id} className="flex items-center justify-between gap-3 px-3 py-2.5 text-xs"><div><div className="font-medium text-slate-700 dark:text-slate-200">{new Date(snapshot.createdAt).toLocaleString('zh-CN', { hour12: false })}</div><div className="text-slate-400">{snapshot.linkCount} 个链接 · {snapshot.categoryCount} 个文件夹</div></div><button onClick={() => { if (confirm('确定恢复这份本地快照吗？')) onRestore(snapshot.links as LinkItem[], snapshot.categories as Category[]); }} className="rounded-lg bg-blue-100 px-2.5 py-1.5 text-blue-700 hover:bg-blue-200 dark:bg-blue-900/30 dark:text-blue-300">恢复</button></div>)}</div>}
             </section>

             <hr className="border-slate-200 dark:border-slate-700" />

            {/* Section 2: Sync Actions */}
            <section className="space-y-4">
                <h4 className="font-medium text-slate-800 dark:text-slate-200">云端同步操作</h4>
                <div className="grid grid-cols-3 gap-4">
                    <button
                        onClick={handleBackupToCloud}
                        disabled={!config.enabled}
                        className="flex flex-col items-center justify-center p-4 rounded-xl border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-700/50 transition-all disabled:opacity-50 disabled:cursor-not-allowed group"
                    >
                        <Upload className="w-8 h-8 text-blue-500 mb-2 group-hover:-translate-y-1 transition-transform" />
                        <span className="text-sm font-medium dark:text-white">上传备份</span>
                        <span className="text-xs text-slate-500 mt-1">覆盖云端数据</span>
                    </button>

                    <button
                        onClick={() => handleRestoreFromCloud()}
                        disabled={!config.enabled}
                        className="flex flex-col items-center justify-center p-4 rounded-xl border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-700/50 transition-all disabled:opacity-50 disabled:cursor-not-allowed group"
                    >
                        <Download className="w-8 h-8 text-purple-500 mb-2 group-hover:-translate-y-1 transition-transform" />
                        <span className="text-sm font-medium dark:text-white">从 WebDAV 恢复</span>
                        <span className="text-xs text-slate-500 mt-1">覆盖本地数据</span>
                    </button>

                    <button 
                        onClick={handleBackupToCloudWithTimestamp}
                        disabled={!config.enabled}
                        className="flex flex-col items-center justify-center p-4 rounded-xl border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-700/50 transition-all disabled:opacity-50 disabled:cursor-not-allowed group"
                    >
                        <Upload className="w-8 h-8 text-green-500 mb-2 group-hover:-translate-y-1 transition-transform" />
                        <span className="text-sm font-medium dark:text-white">双重备份</span>
                        <span className="text-xs text-slate-500 mt-1">带时间戳</span>
                    </button>
                </div>

                {/* 历史备份列表(#2):列出带时间戳的备份,可选择任意一份恢复 */}
                <div className="mt-3">
                    <button
                        onClick={handleListBackups}
                        disabled={!config.enabled || loadingList}
                        className="text-xs text-blue-600 dark:text-blue-400 hover:underline disabled:opacity-50"
                    >
                        {loadingList ? '加载中...' : '查看历史备份'}
                    </button>
                    {backupList.length > 0 && (
                        <div className="mt-2 max-h-32 overflow-y-auto border border-slate-200 dark:border-slate-700 rounded-lg divide-y divide-slate-100 dark:divide-slate-700">
                            {backupList.map(name => (
                                <button
                                    key={name}
                                    onClick={() => handleRestoreFromCloud(name)}
                                    className="w-full flex items-center justify-between px-3 py-2 text-xs hover:bg-slate-50 dark:hover:bg-slate-700/50 transition-colors"
                                >
                                    <span className="font-mono truncate dark:text-slate-300">{name}</span>
                                    <span className="text-purple-500 shrink-0 ml-2">恢复</span>
                                </button>
                            ))}
                        </div>
                    )}
                </div>

                {syncStatus !== 'idle' && (
                    <div className={`text-sm text-center p-2 rounded ${
                        syncStatus === 'success' ? 'bg-green-50 text-green-600 dark:bg-green-900/20' : 
                        syncStatus === 'error' ? 'bg-red-50 text-red-600 dark:bg-red-900/20' : 
                        'bg-blue-50 text-blue-600 dark:bg-blue-900/20'
                    }`}>
                        {statusMsg}
                    </div>
                )}
            </section>

            <hr className="border-slate-200 dark:border-slate-700" />

            {/* Section 2.5: 数据回滚 */}
            <section className="space-y-4">
                <h4 className="font-medium text-slate-800 dark:text-slate-200">数据恢复</h4>
                <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-700/30 flex items-center justify-between">
                    <div>
                        <h5 className="text-sm font-medium dark:text-slate-200">恢复到上一版本</h5>
                        <p className="text-xs text-slate-500 mt-1">云端保存了上一次写入的快照，可用于误操作回滚</p>
                    </div>
                    <button
                        onClick={async () => {
                            if (!confirm('确定要恢复到上一版本吗？当前数据将被覆盖。')) return;
                            try {
                                const res = await fetch('/api/storage?getConfig=prev');
                                if (!res.ok) { alert('获取上一版本失败'); return; }
                                const data = await res.json();
                                if (!data || !data.links) { alert('没有可恢复的上一版本'); return; }
                                onRestore(data.links, data.categories || [], undefined, data.workbenchTools);
                                alert('已恢复到上一版本');
                            } catch { alert('恢复失败'); }
                        }}
                        className="px-4 py-2 bg-amber-500 hover:bg-amber-600 text-white rounded-lg text-sm font-medium transition-colors flex items-center gap-2"
                    >
                        <Download size={16} /> 回滚到上一版本
                    </button>
                </div>
            </section>

            <hr className="border-slate-200 dark:border-slate-700" />

             {/* Section 3: HTML Export */}
             <section className="space-y-4">
                <h4 className="font-medium text-slate-800 dark:text-slate-200">本地导出</h4>
                <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-700/30 flex items-center justify-between">
                    <div>
                        <h5 className="text-sm font-medium dark:text-slate-200">导出 HTML 书签文件</h5>
                        <p className="text-xs text-slate-500 mt-1">兼容 Chrome, Edge, Firefox 导入格式，保留目录结构</p>
                    </div>
                    <button 
                        onClick={handleExportHtml}
                        className="px-4 py-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-600 hover:border-blue-500 text-slate-700 dark:text-slate-200 rounded-lg text-sm font-medium transition-colors flex items-center gap-2"
                    >
                        <Download size={16} /> 导出 HTML
                    </button>
                </div>
                
                <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-700/30 flex items-center justify-between">
                    <div>
                        <h5 className="text-sm font-medium dark:text-slate-200">导出 navix_backup.json 文件</h5>
                        <p className="text-xs text-slate-500 mt-1">与 WebDAV 备份格式一致，账号密码只导出加密密文，恢复后需凭据主密码解锁</p>
                    </div>
                    <button 
                        onClick={handleExportJson}
                        className="px-4 py-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-600 hover:border-blue-500 text-slate-700 dark:text-slate-200 rounded-lg text-sm font-medium transition-colors flex items-center gap-2"
                    >
                        <Download size={16} /> 导出 JSON
                    </button>
                </div>
             </section>

        </div>
      </div>
    </div>
  );
};

export default BackupModal;
