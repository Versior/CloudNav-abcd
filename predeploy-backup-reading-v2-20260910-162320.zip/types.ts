export interface SiteCredential {
  id: string;
  label?: string;
  username?: string;
  account?: string;
  passwordCipher?: string;
  passwordHint?: string;
  remark?: string;
  updatedAt: number;
}

export interface LinkItem {
  id: string;
  title: string;
  url: string;
  icon?: string;
  description?: string;
  categoryId: string;
  tags?: string[];
  aliases?: string[];
  createdAt: number;
  updatedAt?: number;
  deletedAt?: number;
  pinned?: boolean;
  pinnedOrder?: number;
  order?: number;
  visitCount?: number;
  lastVisitedAt?: number;
  note?: string;
  credentials?: SiteCredential[];
  status?: 'unread' | 'read' | 'favorite' | 'archived';
  health?: {
    status: 'unknown' | 'ok' | 'broken' | 'redirected';
    statusCode?: number;
    finalUrl?: string;
    checkedAt?: number;
  };
}

export interface Category {
  id: string;
  name: string;
  icon: string;
  color?: string;
  password?: string;
  parentId?: string;
}

export interface SiteSettings {
  title: string;
  navTitle: string;
  favicon: string;
  cardStyle: 'detailed' | 'simple' | 'list';
  passwordExpiryDays: number; // 密码过期天数，0表示永久不退出
}

export interface AppState {
  links: LinkItem[];
  categories: Category[];
  darkMode: boolean;
  settings?: SiteSettings;
}

export interface WebDavConfig {
  url: string;
  username: string;
  password: string;
  enabled: boolean;
  hasPassword?: boolean;
}

export type AIProvider = 'gemini' | 'openai';

export interface AIConfig {
  provider: AIProvider;
  apiKey: string;
  baseUrl: string;
  model: string;
  hasApiKey?: boolean;
  websiteTitle?: string; // 网站标题 (浏览器标签)
  faviconUrl?: string; // 网站图标URL
  navigationName?: string;
}



// 搜索模式类型
export type SearchMode = 'internal' | 'external';

// 外部搜索源配置
export interface ExternalSearchSource {
  id: string;
  name: string;
  url: string;
  icon?: string;
  enabled: boolean;
  createdAt: number;
}

// 搜索配置
export interface SearchConfig {
  mode: SearchMode;
  externalSources: ExternalSearchSource[];
  selectedSource?: ExternalSearchSource | null; // 选中的搜索源
}

export type DashboardWidgetId = 'stats' | 'folders' | 'activity' | 'tools';

export interface DashboardConfig {
  order: DashboardWidgetId[];
  hidden: DashboardWidgetId[];
}

export interface RssFeed {
  id: string;
  url: string;
  title: string;
  siteUrl?: string;
  icon?: string;
  preset?: boolean;
  addedAt: number;
  lastFetchedAt?: number;
  error?: string;
}

export interface RssArticle {
  id: string;
  feedId: string;
  title: string;
  url: string;
  summary?: string;
  content?: string;
  author?: string;
  sourceTitle?: string;
  publishedAt?: number;
  imageUrl?: string;
  read?: boolean;
  starred?: boolean;
  aiSummary?: string;
  aiBullets?: string[];
  aiFacts?: string[];
  aiActions?: string[];
  aiEvidence?: string[];
  aiTags?: string[];
  aiUpdatedAt?: number;
}

export type ReadingDocumentStatus = 'inbox' | 'later' | 'archive';
export type ReadingDocumentType = 'article' | 'rss' | 'website' | 'note' | 'pdf' | 'video' | 'github';

export interface ReadingHighlight {
  id: string;
  quote: string;
  note?: string;
  tags: string[];
  start?: number;
  end?: number;
  createdAt: number;
  updatedAt: number;
}

export interface ReadingDocument {
  id: string;
  title: string;
  url: string;
  type: ReadingDocumentType;
  status: ReadingDocumentStatus;
  unread: boolean;
  starred: boolean;
  tags: string[];
  content?: string;
  summary?: string;
  author?: string;
  source?: string;
  imageUrl?: string;
  feedId?: string;
  note?: string;
  highlights: ReadingHighlight[];
  progress: number;
  readingPosition: number;
  createdAt: number;
  updatedAt: number;
  deletedAt?: number;
  publishedAt?: number;
  aiSummary?: string;
}

export interface ReadingView {
  id: string;
  name: string;
  query: string;
  pinned: boolean;
  createdAt: number;
  updatedAt: number;
}

export interface RssState {
  feeds: RssFeed[];
  articles: RssArticle[];
}

export interface WorkspaceSyncData {
  rssState?: RssState;
  inspirations?: Inspiration[];
  readLater?: ReadLaterItem[];
  githubWatch?: GithubWatchItem[];
  readingDocuments?: ReadingDocument[];
  workbenchTools?: import('./services/workbenchTools').WorkbenchToolsState;
}

export type InspirationType = 'idea' | 'note' | 'quote' | 'bookmark';
export type InspirationStatus = 'active' | 'archived';

export interface Inspiration {
  id: string;
  title: string;
  content: string;
  type: InspirationType;
  tags: string[];
  sourceUrl?: string;
  sourceTitle?: string;
  status: InspirationStatus;
  createdAt: number;
  updatedAt: number;
  archivedAt?: number;
  aiSummary?: string;
}

export type ReadLaterKind = 'rss' | 'website' | 'github' | 'inspiration';
export type ReadLaterStatus = 'unread' | 'read' | 'archived';

export interface ReadLaterItem {
  id: string;
  kind: ReadLaterKind;
  title: string;
  url: string;
  source?: string;
  summary?: string;
  status: ReadLaterStatus;
  addedAt: number;
  updatedAt: number;
}

export interface GithubWatchItem {
  id: string;
  owner: string;
  repo: string;
  url: string;
  description?: string;
  stars?: number;
  language?: string;
  lastRelease?: string;
  readme?: string;
  lastFetchedAt?: number;
  processedAt?: number;
  error?: string;
}

export type InboxItemKind = 'rss' | 'website' | 'github' | 'inspiration' | 'read-later';

export interface UnifiedInboxItem {
  id: string;
  kind: InboxItemKind;
  title: string;
  summary?: string;
  url?: string;
  source?: string;
  sourceId?: string;
  updatedAt: number;
  read: boolean;
  starred: boolean;
}

export interface AppBootstrapSnapshot {
  links: LinkItem[];
  categories: Category[];
  dashboardConfig: DashboardConfig;
  workbenchTools: import('./services/workbenchTools').WorkbenchToolsState;
  workspace: WorkspaceSyncData;
}

export type AppBootstrapStatus = 'local' | 'hydrating' | 'ready' | 'error';

export const DEFAULT_DASHBOARD_CONFIG: DashboardConfig = {
  order: ['stats', 'folders', 'activity', 'tools'],
  hidden: [],
};

export type HealthFrequency = '6h' | '12h' | 'daily' | 'weekly';
export type HealthScheduleScope = 'all' | 'unchecked' | 'category';

export interface HealthScheduleConfig {
  enabled: boolean;
  frequency: HealthFrequency;
  scope: HealthScheduleScope;
  categoryId?: string;
  maxLinksPerRun: number;
  lastRunAt?: number;
}

export interface HealthRunSummary {
  checked: number;
  ok: number;
  broken: number;
  soft: number;
  redirected: number;
}

export interface HistorySnapshotMeta {
  id: string;
  version: number;
  createdAt: number;
  linkCount: number;
  categoryCount: number;
}

export const INBOX_ID = '__inbox__';
export const FREQUENT_ID = '__frequent__';

export const DEFAULT_CATEGORIES: Category[] = [
  { id: 'common', name: '常用推荐', icon: 'Star' },
  { id: 'sub-search', name: '搜索引擎', icon: 'Search', parentId: 'common' },
  { id: 'sub-news', name: '即时资讯', icon: 'Newspaper', parentId: 'common' },
  { id: 'dev', name: '开发工具', icon: 'Code' },
  { id: 'design', name: '设计资源', icon: 'Palette' },
  { id: 'ent', name: '休闲娱乐', icon: 'Gamepad2' },
  { id: 'ai', name: '人工智能', icon: 'Bot' },
];

export const INITIAL_LINKS: LinkItem[] = [
  // 常用推荐 - 二级分类: 搜索引擎
  { id: 's1', title: 'Google', url: 'https://www.google.com', categoryId: 'sub-search', createdAt: Date.now(), description: '全球最大的搜索引擎', pinned: true, icon: 'https://t3.gstatic.cn/faviconV2?client=SOCIAL&type=FAVICON&fallback_opts=TYPE,SIZE,URL&size=128&url=https://www.google.com' },
  { id: 's2', title: '百度', url: 'https://www.baidu.com', categoryId: 'sub-search', createdAt: Date.now(), description: '国内主流搜索引擎', pinned: true, icon: 'https://t3.gstatic.cn/faviconV2?client=SOCIAL&type=FAVICON&fallback_opts=TYPE,SIZE,URL&size=128&url=https://www.baidu.com' },
  
  // 常用推荐 - 二级分类: 即时资讯
  { id: 'n1', title: 'IT之家', url: 'https://www.ithome.com', categoryId: 'sub-news', createdAt: Date.now(), description: '数码科技资讯平台', pinned: true, icon: 'https://t3.gstatic.cn/faviconV2?client=SOCIAL&type=FAVICON&fallback_opts=TYPE,SIZE,URL&size=128&url=https://www.ithome.com' },
  
  // 开发工具
  { id: '1', title: 'GitHub', url: 'https://github.com', categoryId: 'dev', createdAt: Date.now(), description: '代码托管平台', pinned: true, icon: 'https://t3.gstatic.cn/faviconV2?client=SOCIAL&type=FAVICON&fallback_opts=TYPE,SIZE,URL&size=128&url=https://github.com' },
  { id: '2', title: 'React', url: 'https://react.dev', categoryId: 'dev', createdAt: Date.now(), description: '构建Web用户界面的库', pinned: false, icon: 'https://t3.gstatic.cn/faviconV2?client=SOCIAL&type=FAVICON&fallback_opts=TYPE,SIZE,URL&size=128&url=https://react.dev' },
  
  // 设计资源
  { id: '3', title: 'Tailwind CSS', url: 'https://tailwindcss.com', categoryId: 'design', createdAt: Date.now(), description: '原子化CSS框架', pinned: false, icon: 'https://t3.gstatic.cn/faviconV2?client=SOCIAL&type=FAVICON&fallback_opts=TYPE,SIZE,URL&size=128&url=https://tailwindcss.com' },
  { id: 'd1', title: 'Dribbble', url: 'https://dribbble.com', categoryId: 'design', createdAt: Date.now(), description: '全球设计作品展示社区', pinned: false, icon: 'https://t3.gstatic.cn/faviconV2?client=SOCIAL&type=FAVICON&fallback_opts=TYPE,SIZE,URL&size=128&url=https://dribbble.com' },

  // 休闲娱乐
  { id: 'e1', title: 'Bilibili', url: 'https://www.bilibili.com', categoryId: 'ent', createdAt: Date.now(), description: '国内知名的弹幕视频网站', pinned: false, icon: 'https://t3.gstatic.cn/faviconV2?client=SOCIAL&type=FAVICON&fallback_opts=TYPE,SIZE,URL&size=128&url=https://www.bilibili.com' },
  { id: 'e2', title: 'Steam', url: 'https://store.steampowered.com', categoryId: 'ent', createdAt: Date.now(), description: '数字游戏发行平台', pinned: false, icon: 'https://t3.gstatic.cn/faviconV2?client=SOCIAL&type=FAVICON&fallback_opts=TYPE,SIZE,URL&size=128&url=https://store.steampowered.com' },

  // 人工智能
  { id: '4', title: 'ChatGPT', url: 'https://chat.openai.com', categoryId: 'ai', createdAt: Date.now(), description: 'OpenAI聊天机器人', pinned: true, icon: 'https://t3.gstatic.cn/faviconV2?client=SOCIAL&type=FAVICON&fallback_opts=TYPE,SIZE,URL&size=128&url=https://chat.openai.com' },
  { id: '5', title: 'Gemini', url: 'https://gemini.google.com', categoryId: 'ai', createdAt: Date.now(), description: 'Google DeepMind AI', pinned: true, icon: 'https://t3.gstatic.cn/faviconV2?client=SOCIAL&type=FAVICON&fallback_opts=TYPE,SIZE,URL&size=128&url=https://gemini.google.com' },
];
